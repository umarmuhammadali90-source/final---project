/**
 * ZYDQORA Firebase Ecosystem Configuration
 * Modular Firebase V10 SDK initialization for Auth, Firestore, and Storage.
 * Configured for project: zyvqora-cf33c
 */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js';
import { 
  getAuth, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
  updateProfile
} from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  serverTimestamp,
  onSnapshot
} from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js';
import { 
  getStorage, 
  ref, 
  uploadBytes, 
  getDownloadURL 
} from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js';

// Project Firebase Credentials
export const firebaseConfig = {
  apiKey: "AIzaSyBKXP2EEDWnzzRYQyRXbLdvb5u8FdPNTro",
  authDomain: "zyvqora-cf33c.firebaseapp.com",
  projectId: "zyvqora-cf33c",
  storageBucket: "zyvqora-cf33c.firebasestorage.app",
  messagingSenderId: "95494254561",
  appId: "1:95494254561:web:1f7761db7850dc4a0faca0",
  measurementId: "G-YBQC49Y27T"
};

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);

// Initialize Services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

// System Super Admin Email
export const SUPER_ADMIN_EMAIL = "umardeveloper1@gmail.com";

// Helper to log security events
export async function logSecurityEvent(type, details = {}) {
  try {
    const user = auth.currentUser;
    await addDoc(collection(db, "security_logs"), {
      type,
      userEmail: user ? user.email : "guest",
      userId: user ? user.uid : "anonymous",
      timestamp: serverTimestamp(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      details
    });
  } catch (err) {
    console.warn("Security log notice:", err.message);
  }
}

export {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  signInWithPopup,
  updateProfile,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  onSnapshot,
  ref,
  uploadBytes,
  getDownloadURL
};
