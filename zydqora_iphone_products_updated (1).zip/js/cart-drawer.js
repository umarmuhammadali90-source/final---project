/**
 * ZYDQORA Cart & Payment Split Engine
 * Manages slide-over drawer, local state, and automatic 70/30 bulk split calculation.
 */

class CartDrawer {
  constructor() {
    this.items = JSON.parse(localStorage.getItem('zydqora_cart') || '[]');
    this.isOpen = false;
    this.initUI();
    this.bindEvents();
    this.render();
  }

  save() {
    localStorage.setItem('zydqora_cart', JSON.stringify(this.items));
    this.render();
  }

  addItem(product) {
    const existing = this.items.find(i => i.id === product.id && i.selectedOption === product.selectedOption);
    if (existing) {
      existing.quantity += (product.quantity || 1);
    } else {
      this.items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        selectedOption: product.selectedOption || 'Standard',
        quantity: product.quantity || 1
      });
    }
    this.save();
    this.open();
    if (window.authGuard) {
      window.authGuard.showToast(`Added ${product.name} to your bag.`, 'success');
    }
  }

  removeItem(index) {
    this.items.splice(index, 1);
    this.save();
  }

  updateQty(index, delta) {
    if (!this.items[index]) return;
    this.items[index].quantity += delta;
    if (this.items[index].quantity <= 0) {
      this.removeItem(index);
    } else {
      this.save();
    }
  }

  getTotalCount() {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  getSubtotal() {
    return this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  initUI() {
    if (document.getElementById('zydqora-cart-drawer')) return;

    const drawerHtml = `
      <!-- Slide-over Cart Drawer -->
      <div id="zydqora-cart-backdrop" class="fixed inset-0 bg-black/50 backdrop-blur-sm z-[9995] opacity-0 pointer-events-none transition-opacity duration-300"></div>
      
      <div id="zydqora-cart-drawer" class="fixed top-0 right-0 h-full w-full max-w-md bg-white dark:bg-[#161617] shadow-2xl z-[9996] transform translate-x-full transition-transform duration-300 ease-out border-l border-neutral-200 dark:border-neutral-800 flex flex-col text-neutral-900 dark:text-white">
        <!-- Header -->
        <div class="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
            </svg>
            <h2 class="text-base font-semibold tracking-tight">Review your Bag</h2>
            <span id="cart-item-badge" class="text-xs px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-white/10 font-mono text-neutral-600 dark:text-neutral-300">0</span>
          </div>
          <button id="cart-close-btn" class="w-8 h-8 rounded-full bg-neutral-100 dark:bg-white/10 hover:bg-neutral-200 dark:hover:bg-white/20 flex items-center justify-center transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        <!-- Items List -->
        <div id="cart-items-list" class="flex-1 overflow-y-auto p-6 space-y-4">
          <!-- Dynamic Items -->
        </div>

        <!-- Checkout Summary Footer -->
        <div class="p-6 border-t border-neutral-100 dark:border-neutral-800 bg-neutral-50/50 dark:bg-black/20 space-y-4">
          <div class="space-y-2 text-xs">
            <div class="flex justify-between text-neutral-500 dark:text-neutral-400">
              <span>Subtotal</span>
              <span id="cart-subtotal" class="font-mono text-neutral-900 dark:text-white font-medium">PKR 0</span>
            </div>
            <div class="flex justify-between text-neutral-500 dark:text-neutral-400">
              <span>Shipping (TCS Express)</span>
              <span class="text-emerald-600 dark:text-emerald-400 font-medium">Free Nationwide</span>
            </div>

            <!-- 70/30 Split Indicator Banner -->
            <div id="cart-split-indicator" class="p-3 rounded-2xl bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 space-y-1">
              <div class="flex items-center justify-between text-[11px] font-semibold">
                <span id="split-label">Standard Order (≤5 items)</span>
                <span id="split-badge" class="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-mono text-[10px]">100% COD / Online</span>
              </div>
              <p id="split-desc" class="text-[10px] text-neutral-500 dark:text-neutral-400">Eligible for 100% Cash on Delivery or Full Online Card/Transfer payment.</p>
            </div>
          </div>

          <button id="cart-checkout-btn" class="w-full py-3.5 bg-black dark:bg-white text-white dark:text-black font-semibold text-xs tracking-wide uppercase rounded-2xl hover:opacity-90 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-lg">
            <span>Proceed to Checkout</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
            </svg>
          </button>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', drawerHtml);
  }

  bindEvents() {
    const backdrop = document.getElementById('zydqora-cart-backdrop');
    const closeBtn = document.getElementById('cart-close-btn');
    const checkoutBtn = document.getElementById('cart-checkout-btn');
    const navCartBtn = document.getElementById('nav-cart-trigger');

    navCartBtn?.addEventListener('click', (e) => {
      e.preventDefault();
      this.open();
    });

    closeBtn?.addEventListener('click', () => this.close());
    backdrop?.addEventListener('click', () => this.close());

    checkoutBtn?.addEventListener('click', () => {
      if (this.items.length === 0) {
        if (window.authGuard) window.authGuard.showToast('Your bag is empty.', 'info');
        return;
      }

      if (window.authGuard) {
        window.authGuard.requireAuth(() => {
          this.close();
          window.location.href = '/checkout.html';
        }, '/checkout.html');
      } else {
        window.location.href = '/checkout.html';
      }
    });
  }

  open() {
    this.isOpen = true;
    const drawer = document.getElementById('zydqora-cart-drawer');
    const backdrop = document.getElementById('zydqora-cart-backdrop');
    drawer?.classList.remove('translate-x-full');
    backdrop?.classList.remove('opacity-0', 'pointer-events-none');
    backdrop?.classList.add('opacity-100', 'pointer-events-auto');
  }

  close() {
    this.isOpen = false;
    const drawer = document.getElementById('zydqora-cart-drawer');
    const backdrop = document.getElementById('zydqora-cart-backdrop');
    drawer?.classList.add('translate-x-full');
    backdrop?.classList.add('opacity-0', 'pointer-events-none');
    backdrop?.classList.remove('opacity-100', 'pointer-events-auto');
  }

  render() {
    const list = document.getElementById('cart-items-list');
    const subtotalEl = document.getElementById('cart-subtotal');
    const badge = document.getElementById('cart-item-badge');
    const navBadge = document.getElementById('nav-cart-count');
    const splitLabel = document.getElementById('split-label');
    const splitBadge = document.getElementById('split-badge');
    const splitDesc = document.getElementById('split-desc');

    const totalCount = this.getTotalCount();
    const subtotal = this.getSubtotal();

    if (badge) badge.textContent = totalCount;
    if (navBadge) {
      navBadge.textContent = totalCount;
      if (totalCount > 0) navBadge.classList.remove('hidden');
      else navBadge.classList.add('hidden');
    }

    if (subtotalEl) {
      subtotalEl.textContent = `PKR ${subtotal.toLocaleString()}`;
    }

    // Update Split Rules (>5 items triggers 70% deposit + 30% COD)
    if (splitLabel && splitBadge && splitDesc) {
      if (totalCount > 5) {
        splitLabel.textContent = "Bulk Order Rule (>5 items)";
        splitBadge.className = "px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-500 font-mono text-[10px]";
        splitBadge.textContent = "70% Online + 30% COD";
        const dep70 = Math.round(subtotal * 0.7);
        const cod30 = subtotal - dep70;
        splitDesc.textContent = `Mandatory 70% deposit (PKR ${dep70.toLocaleString()}) via Online Gateway + 30% balance (PKR ${cod30.toLocaleString()}) on Delivery.`;
      } else {
        splitLabel.textContent = "Standard Order (≤5 items)";
        splitBadge.className = "px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-mono text-[10px]";
        splitBadge.textContent = "100% COD / Online";
        splitDesc.textContent = "Eligible for 100% Cash on Delivery or Full Online Card/Transfer payment.";
      }
    }

    if (!list) return;

    if (this.items.length === 0) {
      list.innerHTML = `
        <div class="h-64 flex flex-col items-center justify-center text-center">
          <div class="w-14 h-14 rounded-full bg-neutral-100 dark:bg-white/5 flex items-center justify-center text-neutral-400 mb-3">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
            </svg>
          </div>
          <p class="text-sm font-medium text-neutral-900 dark:text-white">Your Bag is empty.</p>
          <p class="text-xs text-neutral-500 dark:text-neutral-400 mt-1 max-w-[200px]">Explore Apple flagship devices and custom studio creations.</p>
          <a href="/store.html" class="mt-4 px-4 py-2 rounded-full bg-neutral-900 dark:bg-white text-white dark:text-black text-xs font-medium hover:opacity-90 transition-opacity">Browse Store</a>
        </div>
      `;
      return;
    }

    list.innerHTML = this.items.map((item, idx) => `
      <div class="flex gap-4 p-3 rounded-2xl bg-neutral-100/70 dark:bg-white/5 border border-neutral-200/60 dark:border-white/5 items-center">
        <img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-contain rounded-xl bg-white dark:bg-black/40 p-1" />
        <div class="flex-1 min-w-0">
          <h4 class="text-xs font-semibold truncate text-neutral-900 dark:text-white">${item.name}</h4>
          <p class="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">${item.selectedOption}</p>
          <p class="text-xs font-mono font-medium text-neutral-900 dark:text-white mt-1">PKR ${item.price.toLocaleString()}</p>
        </div>
        <div class="flex flex-col items-end gap-2">
          <div class="flex items-center border border-neutral-300 dark:border-neutral-700 rounded-lg overflow-hidden text-xs">
            <button onclick="window.cartDrawer.updateQty(${idx}, -1)" class="px-2 py-0.5 hover:bg-neutral-200 dark:hover:bg-white/10">-</button>
            <span class="px-2 font-mono text-[11px]">${item.quantity}</span>
            <button onclick="window.cartDrawer.updateQty(${idx}, 1)" class="px-2 py-0.5 hover:bg-neutral-200 dark:hover:bg-white/10">+</button>
          </div>
          <button onclick="window.cartDrawer.removeItem(${idx})" class="text-[10px] text-red-500 hover:underline">Remove</button>
        </div>
      </div>
    `).join('');
  }
}

export const cartDrawer = new CartDrawer();
window.cartDrawer = cartDrawer;
