/**
 * ZYDQORA Animated Onboarding Tutorial
 * Powered by GSAP 60fps animations, guiding first-time visitors through
 * the Store, Customizer Studio, and Repair Marketplace.
 * Strictly adheres to Apple Minimalist Aesthetics (Zero Emojis, Pure SVG Icons).
 */
import { gsap } from 'gsap';
import { reviewsAchievements } from './reviews-achievements.js';

export class OnboardingTutorial {
  constructor() {
    this.currentStep = 0;
    this.isAnimating = false;
    this.steps = [
      {
        tag: "Ecosystem Introduction",
        category: "ZYDQORA Blueprint",
        title: "Apple Precision. Re-engineered.",
        description: "Welcome to Pakistan's premier Apple-grade ecosystem. Explore factory-sealed flagship hardware, bespoke 3M vinyl customizer skins, and certified technician repairs with escrow protection.",
        target: null,
        cta: "Explore Store",
        actionUrl: null,
        pills: ["PTA Approved", "Grade 5 Titanium", "70/30 Split"],
        icon: `<svg class="w-6 h-6 text-amber-400" viewBox="0 0 24 24" fill="currentColor"><path d="M15.2 2.2c-.8 1.1-2 1.8-3.4 1.7.2-1.4 1-2.6 2.2-3.3 1.1-.7 2.6-.8 3-.6-.1 1-.7 1.7-1.8 2.2z M12.5 5.5c-4 0-8 3-8.7 7.5-.7 4.5 1.6 8.8 5.6 10.2 2.7.9 6 0 8.3-2.4 1-1 1.6-2.5 1.8-4-2.3-.3-4-2.3-4-4.8s1.7-4.5 4-4.8c-.5-1-3.3-1.7-7-1.7z"/></svg>`
      },
      {
        tag: "01 / Hardware Flagships",
        category: "Store Hub",
        title: "Flagship Inventory & Split Payments",
        description: "Browse official M4 MacBooks, iPhone 16 Pro Max, and Tandem OLED iPads. Standard purchases support 100% Cash-on-Delivery; bulk orders (>5 units) leverage our automated 70% deposit and 30% delivery balance engine.",
        target: "#core-lineup-section",
        cta: "Explore Customizer",
        actionUrl: "/store.html",
        actionLabel: "Visit Store",
        pills: ["A18 Pro 3nm", "100% COD or 70/30", "Instant Trade-In"],
        icon: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>`
      },
      {
        tag: "02 / Studio Customizer",
        category: "Bespoke Covers",
        title: "Micro-Precision Decal Engineering",
        description: "Design customized textured 3M vinyl skins for iPhone, MacBook Lids, and iPad cases. Strip photo backgrounds instantly with AI, apply 360-degree vector decals, and preview laser-cut camera alignments.",
        target: "#customizer-banner-section",
        cta: "Explore Repair Hub",
        actionUrl: "/customize.html",
        actionLabel: "Launch Customizer",
        pills: ["AI Background Stripper", "3M Carbon & Matte", "Snap Alignment"],
        icon: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>`
      },
      {
        tag: "03 / Diagnostic Marketplace",
        category: "Verified Techs",
        title: "Certified Repairs Across Pakistan",
        description: "Post hardware diagnostic gigs for cracked screens, logic board micro-soldering, or battery replacements. Certified technicians bid transparently with 180-day warranty and live 6-stage progress tracking.",
        target: "#repair-marketplace-section",
        cta: "Meet QORA AI",
        actionUrl: "/repair.html",
        actionLabel: "Post Issue",
        pills: ["14,280+ Completed", "180-Day Warranty", "Live SLA Tracker"],
        icon: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/></svg>`
      },
      {
        tag: "04 / Neural Assistance",
        category: "Intelligence",
        title: "QORA AI Gemini Advisor",
        description: "Tap the floating assistant at the bottom-left anytime for hardware spec comparisons, trade-in valuations, skin styling advice, or PTA tax estimations powered by Gemini 3.7.",
        target: "#qora-ai-widget",
        cta: "Complete Tour",
        actionUrl: null,
        pills: ["Gemini 3.7", "Real-Time Calculations", "24/7 Diagnostics"],
        icon: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>`
      }
    ];

    this.initUI();
    this.checkAutoStart();
  }

  initUI() {
    if (document.getElementById('zydqora-onboarding-modal')) return;

    const modalHtml = `
      <div id="zydqora-onboarding-modal" class="fixed inset-0 z-[9998] flex items-end sm:items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-md opacity-0 pointer-events-none transition-opacity duration-300">
        
        <!-- Target Highlight Beacon Overlay -->
        <div id="onboarding-beacon" class="fixed pointer-events-none z-[9997] opacity-0 transition-all duration-500 rounded-3xl border-2 border-white/40 ring-4 ring-white/10 shadow-[0_0_50px_rgba(255,255,255,0.2)]"></div>

        <!-- Glassmorphic Card Container -->
        <div id="onboarding-card" class="w-full max-w-lg bg-white/95 dark:bg-[#141416]/95 border border-neutral-200 dark:border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl text-neutral-900 dark:text-white transform scale-95 relative overflow-hidden backdrop-blur-2xl">
          
          <!-- Subtle Top Accent Light -->
          <div class="absolute -top-16 left-1/2 -translate-x-1/2 w-48 h-16 bg-white/20 dark:bg-white/10 blur-2xl rounded-full pointer-events-none"></div>

          <!-- Header Bar with Step Navigation & Skip -->
          <div class="flex items-center justify-between mb-6 relative z-10">
            <div class="flex items-center gap-2">
              <span class="text-[10px] font-mono tracking-widest uppercase text-neutral-400 dark:text-neutral-500">
                Step <span id="onboarding-step-num">1</span> of ${this.steps.length}
              </span>
              <div class="flex gap-1.5 ml-2" id="onboarding-dots">
                ${this.steps.map((_, i) => `<span class="onboarding-dot h-1 rounded-full transition-all duration-300 ${i === 0 ? 'w-6 bg-neutral-900 dark:bg-white' : 'w-2 bg-neutral-300 dark:bg-white/20'}" data-dot="${i}"></span>`).join('')}
              </div>
            </div>
            
            <button id="onboarding-skip-btn" class="text-xs font-mono uppercase tracking-wider text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors px-2 py-1 rounded-lg hover:bg-neutral-100 dark:hover:bg-white/5">
              Skip
            </button>
          </div>

          <!-- Dynamic Content Body -->
          <div id="onboarding-body" class="space-y-4 relative z-10">
            
            <div class="flex items-start justify-between gap-4">
              <div id="onboarding-icon" class="w-12 h-12 rounded-2xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 flex items-center justify-center shadow-lg ring-1 ring-black/5 dark:ring-white/10 shrink-0">
                ${this.steps[0].icon}
              </div>
              <div class="text-right">
                <span id="onboarding-category" class="text-[10px] font-mono font-semibold px-2.5 py-1 rounded-full bg-neutral-100 dark:bg-white/10 text-neutral-600 dark:text-neutral-300 border border-neutral-200 dark:border-white/10">
                  ${this.steps[0].category}
                </span>
              </div>
            </div>

            <div>
              <span id="onboarding-tag" class="text-[11px] font-mono uppercase tracking-widest text-neutral-400 dark:text-neutral-500 block mb-1">
                ${this.steps[0].tag}
              </span>
              <h3 id="onboarding-title" class="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
                ${this.steps[0].title}
              </h3>
            </div>

            <p id="onboarding-desc" class="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed min-h-[50px]">
              ${this.steps[0].description}
            </p>

            <!-- Feature Pills -->
            <div id="onboarding-pills" class="flex flex-wrap gap-2 pt-1">
              ${this.steps[0].pills.map(pill => `
                <span class="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-white/5 text-[10px] font-medium text-neutral-700 dark:text-neutral-300 border border-neutral-200/60 dark:border-white/5">
                  ${pill}
                </span>
              `).join('')}
            </div>

          </div>

          <!-- Footer Actions Controls -->
          <div class="flex items-center gap-3 mt-6 pt-5 border-t border-neutral-100 dark:border-white/10 relative z-10">
            
            <button id="onboarding-prev-btn" class="px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-white/15 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-white/5 transition-colors hidden">
              Back
            </button>

            <!-- Direct Destination Action Shortcut (Optional) -->
            <a id="onboarding-dest-link" href="#" class="hidden px-4 py-2.5 rounded-xl bg-neutral-100 dark:bg-white/10 hover:bg-neutral-200 dark:hover:bg-white/20 text-xs font-medium text-neutral-900 dark:text-white transition-colors items-center gap-1.5">
              <span id="onboarding-dest-label">Go to Page</span>
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
            </a>

            <button id="onboarding-next-btn" class="flex-1 py-3 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-semibold text-xs tracking-wider uppercase rounded-xl hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-xl">
              <span id="onboarding-btn-text">${this.steps[0].cta}</span>
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </button>

          </div>

        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    this.bindEvents();
  }

  bindEvents() {
    const nextBtn = document.getElementById('onboarding-next-btn');
    const prevBtn = document.getElementById('onboarding-prev-btn');
    const skipBtn = document.getElementById('onboarding-skip-btn');

    nextBtn?.addEventListener('click', () => this.next());
    prevBtn?.addEventListener('click', () => this.prev());
    skipBtn?.addEventListener('click', () => this.finish());

    // Keyboard Shortcuts Navigation
    window.addEventListener('keydown', (e) => {
      const modal = document.getElementById('zydqora-onboarding-modal');
      if (modal && !modal.classList.contains('pointer-events-none')) {
        if (e.key === 'ArrowRight' || e.key === 'Enter') {
          this.next();
        } else if (e.key === 'ArrowLeft') {
          this.prev();
        } else if (e.key === 'Escape') {
          this.finish();
        }
      }
    });

    // Dot indicators direct click
    const dots = document.querySelectorAll('.onboarding-dot');
    dots.forEach((dot, idx) => {
      dot.addEventListener('click', () => {
        if (this.currentStep !== idx && !this.isAnimating) {
          this.goToStep(idx);
        }
      });
    });
  }

  checkAutoStart() {
    const hasCompleted = localStorage.getItem('zydqora_onboarding_completed');
    if (!hasCompleted) {
      setTimeout(() => {
        this.start();
      }, 1200);
    }
  }

  start() {
    this.currentStep = 0;
    const modal = document.getElementById('zydqora-onboarding-modal');
    const card = document.getElementById('onboarding-card');

    if (!modal || !card) return;

    modal.classList.remove('opacity-0', 'pointer-events-none');
    modal.classList.add('opacity-100', 'pointer-events-auto');

    // Smooth GSAP Entry Animation
    gsap.fromTo(card, 
      { y: 30, opacity: 0, scale: 0.94 }, 
      { y: 0, opacity: 1, scale: 1, duration: 0.5, ease: 'power3.out', clearProps: 'transform' }
    );

    this.renderStep(true);
  }

  renderStep(isInitial = false) {
    if (this.isAnimating && !isInitial) return;
    this.isAnimating = true;

    const step = this.steps[this.currentStep];
    const body = document.getElementById('onboarding-body');
    const iconEl = document.getElementById('onboarding-icon');
    const tagEl = document.getElementById('onboarding-tag');
    const categoryEl = document.getElementById('onboarding-category');
    const titleEl = document.getElementById('onboarding-title');
    const descEl = document.getElementById('onboarding-desc');
    const pillsEl = document.getElementById('onboarding-pills');
    const btnText = document.getElementById('onboarding-btn-text');
    const prevBtn = document.getElementById('onboarding-prev-btn');
    const stepNumEl = document.getElementById('onboarding-step-num');
    const destLink = document.getElementById('onboarding-dest-link');
    const destLabel = document.getElementById('onboarding-dest-label');

    const updateDOM = () => {
      if (stepNumEl) stepNumEl.textContent = `${this.currentStep + 1}`;
      if (iconEl) iconEl.innerHTML = step.icon;
      if (tagEl) tagEl.textContent = step.tag;
      if (categoryEl) categoryEl.textContent = step.category;
      if (titleEl) titleEl.textContent = step.title;
      if (descEl) descEl.textContent = step.description;
      if (btnText) btnText.textContent = step.cta;

      if (pillsEl) {
        pillsEl.innerHTML = step.pills.map(pill => `
          <span class="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-white/5 text-[10px] font-medium text-neutral-700 dark:text-neutral-300 border border-neutral-200/60 dark:border-white/5">
            ${pill}
          </span>
        `).join('');
      }

      if (destLink && destLabel) {
        if (step.actionUrl) {
          destLink.href = step.actionUrl;
          destLabel.textContent = step.actionLabel || "Explore";
          destLink.classList.remove('hidden');
          destLink.classList.add('flex');
        } else {
          destLink.classList.add('hidden');
          destLink.classList.remove('flex');
        }
      }

      if (prevBtn) {
        if (this.currentStep > 0) prevBtn.classList.remove('hidden');
        else prevBtn.classList.add('hidden');
      }

      // Smooth Dot indicator updates
      const dots = document.querySelectorAll('#onboarding-dots span');
      dots.forEach((d, idx) => {
        if (idx === this.currentStep) {
          gsap.to(d, { width: 24, backgroundColor: '#ffffff', duration: 0.3, ease: 'power2.out' });
        } else {
          gsap.to(d, { width: 8, backgroundColor: 'rgba(255, 255, 255, 0.2)', duration: 0.3, ease: 'power2.out' });
        }
      });
    };

    if (isInitial) {
      updateDOM();
      this.highlightTarget(step.target);
      this.isAnimating = false;
    } else {
      // 60fps GSAP Text Fade & Slide Transition
      const tl = gsap.timeline({
        onComplete: () => {
          this.isAnimating = false;
        }
      });

      tl.to(body, { opacity: 0, y: -10, duration: 0.18, ease: 'power2.in' })
        .call(updateDOM)
        .to(body, { opacity: 1, y: 0, duration: 0.28, ease: 'power2.out' });

      this.highlightTarget(step.target);
    }
  }

  highlightTarget(targetSelector) {
    const beacon = document.getElementById('onboarding-beacon');
    if (!targetSelector) {
      if (beacon) {
        gsap.to(beacon, { opacity: 0, duration: 0.3 });
      }
      return;
    }

    const targetEl = document.querySelector(targetSelector);
    if (!targetEl) return;

    // Smooth page scrolling to section
    targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });

    // Position spotlight beacon
    setTimeout(() => {
      const rect = targetEl.getBoundingClientRect();
      if (beacon && rect.width > 0 && rect.height > 0) {
        gsap.to(beacon, {
          top: rect.top - 8,
          left: rect.left - 8,
          width: rect.width + 16,
          height: rect.height + 16,
          opacity: 1,
          duration: 0.4,
          ease: 'power3.out'
        });
      }
    }, 400);
  }

  next() {
    if (this.isAnimating) return;
    if (this.currentStep < this.steps.length - 1) {
      this.currentStep++;
      this.renderStep();
    } else {
      this.finish();
    }
  }

  prev() {
    if (this.isAnimating) return;
    if (this.currentStep > 0) {
      this.currentStep--;
      this.renderStep();
    }
  }

  goToStep(index) {
    if (index >= 0 && index < this.steps.length) {
      this.currentStep = index;
      this.renderStep();
    }
  }

  finish() {
    localStorage.setItem('zydqora_onboarding_completed', 'true');
    const modal = document.getElementById('zydqora-onboarding-modal');
    const card = document.getElementById('onboarding-card');
    const beacon = document.getElementById('onboarding-beacon');

    if (beacon) gsap.to(beacon, { opacity: 0, duration: 0.2 });

    if (card && modal) {
      gsap.to(card, {
        y: 20,
        opacity: 0,
        scale: 0.95,
        duration: 0.3,
        ease: 'power2.in',
        onComplete: () => {
          modal.classList.add('opacity-0', 'pointer-events-none');
          modal.classList.remove('opacity-100', 'pointer-events-auto');
        }
      });
    }

    // Award Ecosystem Explorer Achievement Milestone
    if (reviewsAchievements) {
      reviewsAchievements.awardAchievement('ecosystem_explorer');
    }
  }
}

export const onboarding = new OnboardingTutorial();
window.onboarding = onboarding;
window.restartOnboarding = () => onboarding.start();

