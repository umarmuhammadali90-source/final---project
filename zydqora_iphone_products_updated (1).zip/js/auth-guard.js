/**
 * ZYDQORA Gated Authentication & Authorization Engine
 * Enforces guest route locks, Apple-grade auth modal, Super Admin verification,
 * and user profile achievement badges drawer.
 * Strictly adheres to Apple Minimalist Aesthetics (Zero Emojis, Pure SVG Icons).
 */
import { 
  auth, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  signInWithPopup,
  googleProvider,
  updateProfile,
  SUPER_ADMIN_EMAIL,
  logSecurityEvent
} from './firebase-config.js';
import { reviewsAchievements } from './reviews-achievements.js';

class AuthGuard {
  constructor() {
    this.currentUser = null;
    this.redirectAfterAuth = null;
    this.protectedRoutes = ['/store.html', '/buy-product.html', '/customize.html', '/repair.html', '/checkout.html'];
    this.adminRoutes = ['/admin.html'];
    this.initModal();
    this.initProfileModal();
    this.bindEvents();
    this.listenAuthState();
  }

  listenAuthState() {
    onAuthStateChanged(auth, async (user) => {
      this.currentUser = user;
      this.updateNavbarUI(user);
      this.enforceRouteSecurity(user);
      if (user) {
        reviewsAchievements.loadUserAchievements(user.uid);
      }
    });
  }

  isSuperAdmin(user = this.currentUser) {
    return user && user.email && user.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
  }

  isAuthenticated() {
    return !!this.currentUser;
  }

  isLoggedIn() {
    return !!this.currentUser;
  }

  enforceRouteSecurity(user) {
    const currentPath = window.location.pathname.toLowerCase();
    const isProtected = this.protectedRoutes.some(route => currentPath.endsWith(route));
    const isAdmin = this.adminRoutes.some(route => currentPath.endsWith(route));

    if (isAdmin) {
      if (!user) {
        logSecurityEvent('UNAUTHORIZED_ADMIN_ATTEMPT_GUEST', { path: currentPath });
        this.showToast('Super Admin authentication required.', 'error');
        this.openModal('login', '/admin.html');
        return;
      }
      if (!this.isSuperAdmin(user)) {
        logSecurityEvent('FORBIDDEN_ADMIN_ACCESS_ATTEMPT', { userEmail: user.email });
        this.showToast(`Access Denied: ${user.email} is not authorized for Super Admin console.`, 'error');
        setTimeout(() => {
          window.location.href = '/index.html';
        }, 1500);
        return;
      }
    }

    if (isProtected && !user) {
      this.showToast('Please sign in with ZYDQORA ID to access this ecosystem feature.', 'info');
      this.openModal('login', window.location.href);
    }
  }

  initModal() {
    if (document.getElementById('zydqora-auth-modal')) return;

    const modalHtml = `
    <div id="zydqora-auth-modal" class="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md opacity-0 pointer-events-none transition-all duration-300">
      <div id="auth-modal-card" class="w-full max-w-md bg-[#161617]/95 border border-white/10 rounded-3xl p-8 shadow-2xl text-white transform scale-95 transition-all duration-300 relative overflow-hidden backdrop-blur-2xl">
        <!-- Close Button -->
        <button id="auth-modal-close" class="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-gray-400 hover:text-white transition-colors">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>

        <!-- Header -->
        <div class="text-center mb-6">
          <div class="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 mb-3 shadow-inner">
            <svg class="w-6 h-6 text-amber-400" viewBox="0 0 24 24" fill="currentColor">
              <path d="M15.2 2.2c-.8 1.1-2 1.8-3.4 1.7.2-1.4 1-2.6 2.2-3.3 1.1-.7 2.6-.8 3-.6-.1 1-.7 1.7-1.8 2.2z M12.5 5.5c-4 0-8 3-8.7 7.5-.7 4.5 1.6 8.8 5.6 10.2 2.7.9 6 0 8.3-2.4 1-1 1.6-2.5 1.8-4-2.3-.3-4-2.3-4-4.8s1.7-4.5 4-4.8c-.5-1-3.3-1.7-7-1.7z"/>
            </svg>
          </div>
          <h2 class="text-2xl font-semibold tracking-tight text-white" id="auth-modal-title">Sign in to ZYDQORA</h2>
          <p class="text-xs text-gray-400 mt-1" id="auth-modal-subtitle">Your gateway to the Apple-grade e-commerce, customization & repair ecosystem.</p>
        </div>

        <!-- Tab Controls -->
        <div class="flex p-1 bg-white/5 rounded-xl mb-6 border border-white/10">
          <button id="tab-login-btn" class="flex-1 py-2 text-xs font-medium rounded-lg transition-all duration-200 bg-white text-black shadow">Sign In</button>
          <button id="tab-signup-btn" class="flex-1 py-2 text-xs font-medium rounded-lg transition-all duration-200 text-gray-400 hover:text-white">Create ID</button>
        </div>

        <!-- Auth Form -->
        <form id="zydqora-auth-form" class="space-y-4">
          <div id="auth-name-field" class="hidden">
            <label class="block text-[11px] font-medium uppercase tracking-wider text-gray-400 mb-1">Full Name</label>
            <input type="text" id="auth-name-input" placeholder="Muhammad Umar" class="w-full px-4 py-2.5 bg-white/5 border border-white/15 rounded-xl text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white transition-colors" />
          </div>

          <div>
            <label class="block text-[11px] font-medium uppercase tracking-wider text-gray-400 mb-1">ZYDQORA ID (Email)</label>
            <input type="email" id="auth-email-input" required placeholder="name@example.com" class="w-full px-4 py-2.5 bg-white/5 border border-white/15 rounded-xl text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white transition-colors" />
          </div>

          <div>
            <div class="flex items-center justify-between mb-1">
              <label class="block text-[11px] font-medium uppercase tracking-wider text-gray-400">Password</label>
              <a href="#" id="auth-forgot-link" class="text-[11px] text-gray-400 hover:text-white transition-colors">Forgot?</a>
            </div>
            <input type="password" id="auth-password-input" required placeholder="••••••••" class="w-full px-4 py-2.5 bg-white/5 border border-white/15 rounded-xl text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white transition-colors" />
          </div>

          <div id="auth-error-msg" class="hidden text-xs text-red-400 bg-red-950/40 border border-red-800/50 p-2.5 rounded-xl"></div>

          <button type="submit" id="auth-submit-btn" class="w-full py-3 bg-white text-black font-medium text-sm rounded-xl hover:bg-gray-100 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-lg shadow-white/5">
            <span>Continue</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
            </svg>
          </button>
        </form>

        <!-- Divider -->
        <div class="relative my-6">
          <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-white/10"></div></div>
          <div class="relative flex justify-center text-[10px] uppercase"><span class="bg-[#161617] px-2 text-gray-500">Or continue with</span></div>
        </div>

        <!-- Google OAuth Button -->
        <button id="google-auth-btn" class="w-full py-2.5 bg-white/5 border border-white/15 text-white text-xs font-medium rounded-xl hover:bg-white/10 active:scale-[0.99] transition-all flex items-center justify-center gap-3">
          <svg class="w-4 h-4" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
          </svg>
          <span>Google Account</span>
        </button>

        <div class="mt-5 text-center text-[10px] text-gray-500">
          Super Admin: <span class="text-gray-400 font-mono">umardeveloper1@gmail.com</span>
        </div>
      </div>
    </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  initProfileModal() {
    if (document.getElementById('zydqora-profile-modal')) return;

    const modalHtml = `
    <div id="zydqora-profile-modal" class="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md opacity-0 pointer-events-none transition-all duration-300">
      <div id="profile-modal-card" class="w-full max-w-2xl bg-white dark:bg-[#161617] border border-neutral-200 dark:border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl text-neutral-900 dark:text-white transform scale-95 transition-all duration-300 relative overflow-hidden max-h-[90vh] flex flex-col">
        
        <button id="profile-modal-close" class="absolute top-5 right-5 w-8 h-8 rounded-full bg-neutral-100 dark:bg-white/10 hover:bg-neutral-200 dark:hover:bg-white/20 flex items-center justify-center text-neutral-500 dark:text-neutral-400 hover:text-black dark:hover:text-white transition-colors z-10">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>

        <!-- Profile Overview Header -->
        <div class="flex items-center gap-4 mb-4 pb-4 border-b border-neutral-100 dark:border-white/10 shrink-0">
          <div id="profile-avatar-circle" class="w-14 h-14 rounded-2xl bg-neutral-900 text-white dark:bg-white dark:text-black font-bold text-xl flex items-center justify-center uppercase shadow-md ring-1 ring-black/10 dark:ring-white/20">
            U
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2">
              <h3 class="text-lg font-bold text-neutral-900 dark:text-white truncate" id="profile-user-name">User Account</h3>
              <span id="profile-admin-badge" class="hidden text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-neutral-900 text-white dark:bg-white dark:text-black border border-neutral-700">SUPER ADMIN</span>
            </div>
            <p class="text-xs text-neutral-500 dark:text-neutral-400 font-mono truncate" id="profile-user-email">email@domain.com</p>
          </div>
        </div>

        <!-- Ecosystem 'My Achievements' Section -->
        <div id="user-achievements-container" class="flex-1 overflow-y-auto pr-1 space-y-3">
          <!-- Rendered dynamically by renderMyAchievements -->
        </div>

        <div class="mt-4 pt-4 border-t border-neutral-100 dark:border-white/10 flex justify-between items-center text-xs shrink-0">
          <div class="flex items-center gap-2 text-neutral-400 text-[11px]">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            <span>Apple Silicon Security Verified</span>
          </div>
          <button id="profile-logout-btn" class="text-red-500 hover:underline font-medium">Sign Out</button>
        </div>
      </div>
    </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  bindEvents() {
    const modal = document.getElementById('zydqora-auth-modal');
    const closeBtn = document.getElementById('auth-modal-close');
    const tabLogin = document.getElementById('tab-login-btn');
    const tabSignup = document.getElementById('tab-signup-btn');
    const form = document.getElementById('zydqora-auth-form');
    const googleBtn = document.getElementById('google-auth-btn');

    const profileModal = document.getElementById('zydqora-profile-modal');
    const profileClose = document.getElementById('profile-modal-close');
    const profileLogout = document.getElementById('profile-logout-btn');

    let currentTab = 'login';

    const switchTab = (tab) => {
      currentTab = tab;
      const nameField = document.getElementById('auth-name-field');
      const title = document.getElementById('auth-modal-title');
      const submitText = document.getElementById('auth-submit-btn').querySelector('span');

      if (tab === 'signup') {
        tabSignup.className = "flex-1 py-2 text-xs font-medium rounded-lg transition-all duration-200 bg-white text-black shadow";
        tabLogin.className = "flex-1 py-2 text-xs font-medium rounded-lg transition-all duration-200 text-gray-400 hover:text-white";
        nameField.classList.remove('hidden');
        title.textContent = "Create your ZYDQORA ID";
        submitText.textContent = "Create Account";
      } else {
        tabLogin.className = "flex-1 py-2 text-xs font-medium rounded-lg transition-all duration-200 bg-white text-black shadow";
        tabSignup.className = "flex-1 py-2 text-xs font-medium rounded-lg transition-all duration-200 text-gray-400 hover:text-white";
        nameField.classList.add('hidden');
        title.textContent = "Sign in to ZYDQORA";
        submitText.textContent = "Continue";
      }
      this.clearError();
    };

    tabLogin?.addEventListener('click', () => switchTab('login'));
    tabSignup?.addEventListener('click', () => switchTab('signup'));

    closeBtn?.addEventListener('click', () => this.closeModal());
    modal?.addEventListener('click', (e) => {
      if (e.target === modal) this.closeModal();
    });

    profileClose?.addEventListener('click', () => this.closeProfileModal());
    profileModal?.addEventListener('click', (e) => {
      if (e.target === profileModal) this.closeProfileModal();
    });
    profileLogout?.addEventListener('click', async () => {
      await signOut(auth);
      this.closeProfileModal();
      this.showToast('Signed out of ZYDQORA ID.', 'info');
    });

    form?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('auth-email-input').value.trim();
      const password = document.getElementById('auth-password-input').value;
      const name = document.getElementById('auth-name-input')?.value.trim();
      const submitBtn = document.getElementById('auth-submit-btn');

      this.clearError();
      submitBtn.disabled = true;
      submitBtn.classList.add('opacity-70');

      try {
        if (currentTab === 'signup') {
          const cred = await createUserWithEmailAndPassword(auth, email, password);
          if (name && cred.user) {
            await updateProfile(cred.user, { displayName: name });
          }
          this.showToast('ZYDQORA ID created successfully.', 'success');
        } else {
          await signInWithEmailAndPassword(auth, email, password);
          this.showToast('Signed in successfully.', 'success');
        }
        this.closeModal();
        if (this.redirectAfterAuth) {
          window.location.href = this.redirectAfterAuth;
        }
      } catch (err) {
        this.showError(err.message.replace('Firebase:', '').trim());
      } finally {
        submitBtn.disabled = false;
        submitBtn.classList.remove('opacity-70');
      }
    });

    googleBtn?.addEventListener('click', async () => {
      try {
        await signInWithPopup(auth, googleProvider);
        this.showToast('Google authentication verified.', 'success');
        this.closeModal();
        if (this.redirectAfterAuth) {
          window.location.href = this.redirectAfterAuth;
        }
      } catch (err) {
        this.showError(err.message);
      }
    });
  }

  openModal(tab = 'login', redirectUrl = null) {
    this.redirectAfterAuth = redirectUrl;
    const modal = document.getElementById('zydqora-auth-modal');
    const card = document.getElementById('auth-modal-card');
    if (!modal || !card) return;

    if (tab === 'signup') {
      document.getElementById('tab-signup-btn')?.click();
    } else {
      document.getElementById('tab-login-btn')?.click();
    }

    modal.classList.remove('opacity-0', 'pointer-events-none');
    card.classList.remove('scale-95');
    card.classList.add('scale-100');
  }

  closeModal() {
    const modal = document.getElementById('zydqora-auth-modal');
    const card = document.getElementById('auth-modal-card');
    if (!modal || !card) return;

    modal.classList.add('opacity-0', 'pointer-events-none');
    card.classList.remove('scale-100');
    card.classList.add('scale-95');
    this.clearError();
  }

  async openProfileModal() {
    if (!this.currentUser) {
      this.openModal('login');
      return;
    }

    const modal = document.getElementById('zydqora-profile-modal');
    const card = document.getElementById('profile-modal-card');
    const avatar = document.getElementById('profile-avatar-circle');
    const nameEl = document.getElementById('profile-user-name');
    const emailEl = document.getElementById('profile-user-email');
    const adminBadge = document.getElementById('profile-admin-badge');

    const user = this.currentUser;
    const isSuper = this.isSuperAdmin(user);

    if (avatar) avatar.textContent = user.displayName ? user.displayName.charAt(0) : (user.email ? user.email.charAt(0) : 'U');
    if (nameEl) nameEl.textContent = user.displayName || 'ZYDQORA Member';
    if (emailEl) emailEl.textContent = user.email;
    if (adminBadge) {
      if (isSuper) adminBadge.classList.remove('hidden');
      else adminBadge.classList.add('hidden');
    }

    // Render 'My Achievements' section with elegant monochrome badges from Firestore
    await reviewsAchievements.renderMyAchievementsSection('user-achievements-container', user.uid);

    modal?.classList.remove('opacity-0', 'pointer-events-none');
    card?.classList.remove('scale-95');
    card?.classList.add('scale-100');
  }

  closeProfileModal() {
    const modal = document.getElementById('zydqora-profile-modal');
    const card = document.getElementById('profile-modal-card');
    modal?.classList.add('opacity-0', 'pointer-events-none');
    card?.classList.remove('scale-100');
    card?.classList.add('scale-95');
  }

  showError(msg) {
    const el = document.getElementById('auth-error-msg');
    if (el) {
      el.textContent = msg;
      el.classList.remove('hidden');
    }
  }

  clearError() {
    const el = document.getElementById('auth-error-msg');
    if (el) el.classList.add('hidden');
  }

  updateNavbarUI(user) {
    const authBtn = document.getElementById('nav-auth-btn');
    if (!authBtn) return;

    if (user) {
      const isSuper = this.isSuperAdmin(user);
      authBtn.innerHTML = `
        <div class="relative group cursor-pointer" id="user-profile-trigger">
          <div class="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/15 border border-black/10 dark:border-white/15 transition-colors">
            <div class="w-6 h-6 rounded-full bg-neutral-800 text-white text-[11px] font-semibold flex items-center justify-center uppercase">
              ${user.displayName ? user.displayName.charAt(0) : (user.email ? user.email.charAt(0) : 'U')}
            </div>
            <span class="text-xs font-medium text-neutral-800 dark:text-neutral-200 hidden md:inline max-w-[90px] truncate">
              ${user.displayName || user.email.split('@')[0]}
            </span>
            ${isSuper ? '<span class="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono font-bold">ADMIN</span>' : ''}
          </div>

          <!-- Dropdown -->
          <div class="absolute right-0 mt-2 w-60 py-2 bg-white/95 dark:bg-[#1C1C1E]/95 backdrop-blur-xl border border-black/10 dark:border-white/10 rounded-2xl shadow-xl opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all z-50">
            <div class="px-4 py-2 border-b border-black/5 dark:border-white/5">
              <p class="text-xs font-semibold text-neutral-900 dark:text-white truncate">${user.displayName || 'ZYDQORA User'}</p>
              <p class="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">${user.email}</p>
            </div>
            <button id="open-achievements-btn" class="w-full flex items-center gap-2 px-4 py-2 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-left">
              <svg class="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V4a2 2 0 10-2 2h2zm0 13l-4-4m4 4l4-4"/></svg>
              <span>Achievements & Profile</span>
            </button>
            ${isSuper ? `
              <a href="/admin.html" class="flex items-center gap-2 px-4 py-2 text-xs font-medium text-amber-500 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                <span>Super Admin Console</span>
              </a>
            ` : ''}
            <a href="/store.html" class="flex items-center gap-2 px-4 py-2 text-xs text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
              <span>Apple Store Hub</span>
            </a>
            <a href="/customize.html" class="flex items-center gap-2 px-4 py-2 text-xs text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>
              <span>Studio Customizer</span>
            </a>
            <a href="/repair.html" class="flex items-center gap-2 px-4 py-2 text-xs text-neutral-700 dark:text-neutral-300 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/></svg>
              <span>Repair Marketplace</span>
            </a>
            <button id="signout-btn" class="w-full flex items-center gap-2 px-4 py-2 text-xs text-red-500 hover:bg-red-500/10 transition-colors text-left border-t border-black/5 dark:border-white/5 mt-1">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      `;

      document.getElementById('open-achievements-btn')?.addEventListener('click', () => this.openProfileModal());
      document.getElementById('signout-btn')?.addEventListener('click', async () => {
        await signOut(auth);
        this.showToast('Signed out of ZYDQORA ID.', 'info');
      });
    } else {
      authBtn.innerHTML = `
        <button id="login-trigger-btn" class="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 border border-black/10 dark:border-white/15 text-xs font-medium text-neutral-800 dark:text-white transition-all active:scale-95">
          <svg class="w-4 h-4 text-neutral-600 dark:text-neutral-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
          </svg>
          <span>Sign In</span>
        </button>
      `;

      document.getElementById('login-trigger-btn')?.addEventListener('click', () => {
        this.openModal('login');
      });
    }
  }

  showToast(message, type = 'info') {
    let toastContainer = document.getElementById('zydqora-toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.id = 'zydqora-toast-container';
      toastContainer.className = 'fixed bottom-6 right-6 z-[10000] flex flex-col gap-2 pointer-events-none';
      document.body.appendChild(toastContainer);
    }

    const toast = document.createElement('div');
    const colorClass = type === 'error' ? 'bg-red-950/90 border-red-800/80 text-red-200' :
                       type === 'success' ? 'bg-emerald-950/90 border-emerald-800/80 text-emerald-200' :
                       'bg-neutral-900/95 border-white/20 text-white';

    toast.className = `px-4 py-3 rounded-2xl border backdrop-blur-xl shadow-2xl text-xs font-medium max-w-sm transform translate-y-4 opacity-0 transition-all duration-300 pointer-events-auto flex items-center gap-2.5 ${colorClass}`;
    toast.innerHTML = `
      <span>${message}</span>
    `;

    toastContainer.appendChild(toast);

    requestAnimationFrame(() => {
      toast.classList.remove('translate-y-4', 'opacity-0');
    });

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  requireAuth(actionCallback, targetPath = window.location.href) {
    if (this.currentUser) {
      actionCallback(this.currentUser);
    } else {
      this.showToast('Please sign in to proceed.', 'info');
      this.openModal('login', targetPath);
    }
  }
}

export const authGuard = new AuthGuard();
window.authGuard = authGuard;
window.openAuthModal = (tab, redirect) => authGuard.openModal(tab, redirect);
window.requireAuth = (callback, target) => authGuard.requireAuth(callback, target);
