/**
 * ZYDQORA Hardware Layer Disassembly Experience
 * Uses GSAP ScrollTrigger to explode and inspect internal device architecture.
 */
import { gsap } from 'gsap';

export function initScrollDisassembly() {
  const container = document.getElementById('disassembly-section');
  if (!container) return;

  const layers = [
    { id: 'layer-titanium', z: 120, rot: -5, opacity: 0.95 },
    { id: 'layer-ceramic', z: 60, rot: 2, opacity: 0.9 },
    { id: 'layer-chip', z: 0, rot: 0, opacity: 1 },
    { id: 'layer-thermal', z: -60, rot: -3, opacity: 0.9 },
    { id: 'layer-camera', z: -120, rot: 4, opacity: 0.95 }
  ];

  // Disassembly Range Slider
  const slider = document.getElementById('disassembly-slider');
  const explodeBtn = document.getElementById('explode-toggle-btn');
  let isExploded = false;

  function updateLayerTransforms(progress) {
    layers.forEach((layer) => {
      const el = document.getElementById(layer.id);
      if (!el) return;

      const offsetMultiplier = progress; // 0 to 1
      const translateZ = layer.z * offsetMultiplier * 2.5;
      const translateY = (layer.z * 0.4) * offsetMultiplier * -1;
      const rotate = layer.rot * offsetMultiplier;
      const scale = 1 - Math.abs(layer.z) * 0.0008 * offsetMultiplier;

      el.style.transform = `perspective(1000px) translateY(${translateY}px) translateZ(${translateZ}px) rotateY(${rotate}deg) scale(${scale})`;
      el.style.boxShadow = offsetMultiplier > 0.2 
        ? `0 ${20 * offsetMultiplier}px ${40 * offsetMultiplier}px rgba(0,0,0,0.4)`
        : '0 10px 25px rgba(0,0,0,0.1)';
    });

    // Update active highlight card based on progress
    const cards = document.querySelectorAll('.hardware-spec-card');
    const activeIndex = Math.min(Math.floor(progress * 5), 4);
    cards.forEach((card, idx) => {
      if (idx === activeIndex) {
        card.classList.add('border-white', 'dark:border-white', 'bg-black/10', 'dark:bg-white/10');
        card.classList.remove('border-neutral-200', 'dark:border-neutral-800');
      } else {
        card.classList.remove('border-white', 'dark:border-white', 'bg-black/10', 'dark:bg-white/10');
        card.classList.add('border-neutral-200', 'dark:border-neutral-800');
      }
    });
  }

  slider?.addEventListener('input', (e) => {
    const val = parseFloat(e.target.value) / 100;
    updateLayerTransforms(val);
  });

  explodeBtn?.addEventListener('click', () => {
    isExploded = !isExploded;
    const targetVal = isExploded ? 100 : 0;
    if (slider) slider.value = targetVal;
    
    gsap.to({ val: isExploded ? 0 : 1 }, {
      val: isExploded ? 1 : 0,
      duration: 0.8,
      ease: 'power3.out',
      onUpdate: function() {
        updateLayerTransforms(this.targets()[0].val);
      }
    });

    explodeBtn.textContent = isExploded ? 'Assemble Layers' : 'Explode Architecture';
  });

  // Initial render
  updateLayerTransforms(0.4);
}
