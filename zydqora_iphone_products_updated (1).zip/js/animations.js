/**
 * ZYDQORA Apple-Grade Motion & Scroll Reveal Engine
 * Designed for pure Apple aesthetic, 60/120fps hardware acceleration,
 * page load entrance choreography, scroll-triggered staggered reveals,
 * spring micro-interactions, and IntersectionObserver resilience.
 */
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export class ZydqoraMotionEngine {
  constructor() {
    this.isInitialized = false;
    this.init();
  }

  init() {
    if (this.isInitialized) return;
    this.isInitialized = true;

    // 1. Inject global animation styles & spring easing
    this.injectStyles();

    // 2. Attach classes to major elements across the page
    this.tagDomElements();

    // 3. Page Load Entrance Choreography (Initial Mount)
    this.initPageLoadSequence();

    // 4. Scroll-Triggered Reveal Animations (GSAP ScrollTrigger + IntersectionObserver)
    this.initScrollReveals();

    // 5. Micro-Interactions & Hover Physics
    this.initMicroInteractions();
  }

  injectStyles() {
    if (document.getElementById('zydqora-motion-styles')) return;
    const styleEl = document.createElement('style');
    styleEl.id = 'zydqora-motion-styles';
    styleEl.textContent = `
      /* Apple Timing Functions */
      :root {
        --apple-ease: cubic-bezier(0.16, 1, 0.3, 1);
        --apple-spring: cubic-bezier(0.175, 0.885, 0.32, 1.275);
      }

      /* 1. Scroll Reveal Baseline States */
      .reveal-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.7s var(--apple-ease), transform 0.7s var(--apple-ease);
        will-change: opacity, transform;
      }
      .reveal-on-scroll.animate-in {
        opacity: 1 !important;
        transform: translateY(0) !important;
      }

      .reveal-heading {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.7s var(--apple-ease), transform 0.7s var(--apple-ease);
        will-change: opacity, transform;
      }
      .reveal-heading.animate-in {
        opacity: 1 !important;
        transform: translateY(0) !important;
      }

      .reveal-scale {
        opacity: 0;
        transform: scale(0.96);
        transition: opacity 0.8s var(--apple-ease), transform 0.8s var(--apple-ease);
        will-change: opacity, transform;
      }
      .reveal-scale.animate-in {
        opacity: 1 !important;
        transform: scale(1) !important;
      }

      .reveal-left {
        opacity: 0;
        transform: translateX(-30px);
        transition: opacity 0.7s var(--apple-ease), transform 0.7s var(--apple-ease);
        will-change: opacity, transform;
      }
      .reveal-left.animate-in {
        opacity: 1 !important;
        transform: translateX(0) !important;
      }

      .reveal-right {
        opacity: 0;
        transform: translateX(30px);
        transition: opacity 0.7s var(--apple-ease), transform 0.7s var(--apple-ease);
        will-change: opacity, transform;
      }
      .reveal-right.animate-in {
        opacity: 1 !important;
        transform: translateX(0) !important;
      }

      /* 2. Staggered Product Cards & Grid Children */
      .stagger-card {
        opacity: 0;
        transform: translateY(40px);
        transition: opacity 0.65s var(--apple-ease), transform 0.65s var(--apple-ease);
        will-change: opacity, transform;
      }
      .stagger-card.animate-in {
        opacity: 1 !important;
        transform: translateY(0) !important;
      }

      /* 3. Micro-Interactions: Cards & Tiles Hover States */
      .apple-hover-card {
        transition: transform 0.35s var(--apple-ease), box-shadow 0.35s var(--apple-ease), border-color 0.35s var(--apple-ease) !important;
        will-change: transform, box-shadow;
      }
      .apple-hover-card:hover {
        transform: translateY(-6px) scale(1.015) !important;
        box-shadow: 0 20px 30px -10px rgba(0, 0, 0, 0.45), 0 0 0 1px rgba(255, 255, 255, 0.2) !important;
      }

      /* 4. Micro-Interactions: Buttons & Primary CTAs */
      .apple-btn-interactive {
        transition: transform 0.2s var(--apple-ease), background-color 0.2s ease, opacity 0.2s ease, box-shadow 0.2s ease !important;
        will-change: transform;
      }
      .apple-btn-interactive:hover {
        transform: scale(1.03) !important;
      }
      .apple-btn-interactive:active {
        transform: scale(0.96) !important;
      }

      /* 5. Micro-Interactions: Mega Dropdown Nav Menu */
      .apple-mega-menu {
        opacity: 0 !important;
        transform: translateY(-8px) !important;
        pointer-events: none !important;
        transition: opacity 0.25s ease, transform 0.35s var(--apple-spring) !important;
      }
      .group:hover > .apple-mega-menu,
      .group:hover .apple-mega-menu {
        opacity: 1 !important;
        transform: translateY(0) !important;
        pointer-events: auto !important;
      }
    `;
    document.head.appendChild(styleEl);
  }

  tagDomElements() {
    // 1. Tag Section Headings
    const sectionHeadings = document.querySelectorAll(`
      #core-lineup-section h2,
      #disassembly-section h2,
      #customizer-banner-section h2,
      #repair-marketplace-section h2,
      #reviews-section h2,
      #installments h2,
      #pakistan-network h2,
      #about-section h2
    `);
    sectionHeadings.forEach(h => h.classList.add('reveal-heading'));

    // 2. Tag Feature Banners & Complex Containers
    const featureBanners = document.querySelectorAll(`
      #customizer-banner-section > div,
      #disassembly-section,
      #installments > div,
      #pakistan-network > div:last-child,
      #about-section > div
    `);
    featureBanners.forEach(b => b.classList.add('reveal-scale'));

    // 3. Tag Product Grid Children
    const lineupCards = document.querySelectorAll('#core-lineup-section .grid > div');
    lineupCards.forEach(c => {
      c.classList.add('stagger-card', 'apple-hover-card');
    });

    const reviewsCards = document.querySelectorAll('#homepage-reviews-grid > div');
    reviewsCards.forEach(c => {
      c.classList.add('stagger-card', 'apple-hover-card');
    });

    // 4. Tag Repair Marketplace Cards (Horizontal slide-in)
    const repairStats = document.querySelectorAll('#repair-marketplace-section .grid-cols-1.sm\\:grid-cols-2.lg\\:grid-cols-4 > div');
    repairStats.forEach((card, index) => {
      card.classList.add(index % 2 === 0 ? 'reveal-left' : 'reveal-right', 'apple-hover-card');
    });

    const repairSteps = document.querySelectorAll('#repair-marketplace-section .grid-cols-1.md\\:grid-cols-3 > div');
    repairSteps.forEach(step => {
      step.classList.add('reveal-on-scroll');
    });

    // 5. Tag Hardware Spec Cards
    const hardwareCards = document.querySelectorAll('.hardware-spec-card');
    hardwareCards.forEach(card => card.classList.add('apple-hover-card', 'reveal-on-scroll'));

    // 6. Tag All Buttons & Interactive Links
    const buttons = document.querySelectorAll(`
      button:not([disabled]),
      #hero-slide-1 a,
      #hero-slide-1 button,
      #calc-apply-btn,
      #calc-download-quote-btn,
      #compare-all-lineup-btn,
      .compare-specs-card-btn,
      #explode-toggle-btn
    `);
    buttons.forEach(btn => btn.classList.add('apple-btn-interactive'));

    // 7. Tag Mega Dropdown Menus
    const dropdowns = document.querySelectorAll('header nav .group > div');
    dropdowns.forEach(dd => dd.classList.add('apple-mega-menu'));
  }

  /**
   * PAGE LOAD ENTRANCE ANIMATIONS (INITIAL MOUNT)
   */
  initPageLoadSequence() {
    // 1. Sticky Navigation:
    // Slide down from top: y: -100 -> y: 0, opacity: 0 -> 1, duration: 0.6s, ease: [0.16, 1, 0.3, 1]
    const header = document.querySelector('header');
    if (header) {
      gsap.fromTo(
        header,
        { y: -100, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, ease: 'power4.out' }
      );
    }

    // Top announcement banner
    const announcement = document.querySelector('aside[aria-label="Announcement"]');
    if (announcement) {
      gsap.fromTo(
        announcement,
        { y: -25, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, delay: 0.05, ease: 'power3.out' }
      );
    }

    // 2. Hero Section (Staggered Reveal):
    const heroSlide = document.getElementById('hero-slide-1');
    if (heroSlide) {
      const eyebrow = heroSlide.querySelector('span:first-child');
      const headline = heroSlide.querySelector('h1');
      const subtitle = heroSlide.querySelector('p');
      const ctaButtons = heroSlide.querySelectorAll('.flex.items-center.justify-center.gap-6 a, .flex.items-center.justify-center.gap-6 button');
      const heroImage = heroSlide.querySelector('img');

      // Eyebrow Badge: Scale up 0.95 -> 1, opacity: 0 -> 1, delay: 0.1s
      if (eyebrow) {
        gsap.fromTo(
          eyebrow,
          { scale: 0.95, opacity: 0 },
          { scale: 1, opacity: 1, duration: 0.5, delay: 0.1, ease: 'power3.out' }
        );
      }

      // Headline ("ZYDQORA"): Slide up 30px -> 0px, opacity: 0 -> 1, delay: 0.2s
      if (headline) {
        gsap.fromTo(
          headline,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, delay: 0.2, ease: 'power4.out' }
        );
      }

      // Subtitle & Tagline: Slide up 20px -> 0px, opacity: 0 -> 1, delay: 0.35s
      if (subtitle) {
        gsap.fromTo(
          subtitle,
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, delay: 0.35, ease: 'power3.out' }
        );
      }

      // Call-to-Action Buttons: Staggered pop-in with spring physics (stiffness: 260, damping: 20)
      if (ctaButtons.length > 0) {
        gsap.fromTo(
          ctaButtons,
          { scale: 0.8, opacity: 0, y: 15 },
          {
            scale: 1,
            opacity: 1,
            y: 0,
            duration: 0.5,
            delay: 0.45,
            stagger: 0.08,
            ease: 'back.out(1.8)'
          }
        );
      }

      // Hero Image / Showcase Visual: Scale 0.9 -> 1.0, opacity: 0 -> 1, duration: 1s, delay: 0.4s
      if (heroImage) {
        gsap.fromTo(
          heroImage,
          { scale: 0.9, opacity: 0 },
          { scale: 1.0, opacity: 1, duration: 1.0, delay: 0.4, ease: 'power3.out' }
        );
      }
    }
  }

  /**
   * SCROLL-TRIGGERED REVEAL ANIMATIONS (ON SCROLL)
   */
  initScrollReveals() {
    // 1. High-Performance IntersectionObserver Fallback Engine
    const observerOptions = { threshold: 0.15, rootMargin: '0px 0px -50px 0px' };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    document.querySelectorAll(`
      .reveal-on-scroll,
      .reveal-heading,
      .reveal-scale,
      .reveal-left,
      .reveal-right
    `).forEach((el) => observer.observe(el));

    // 2. Product Grids & Categories (Staggered Children via ScrollTrigger)
    // Parent Container: Triggers when 20% in view (amount: 0.2 / start: 'top 80%')
    // Children Cards: Stagger delay of 0.08s between each product card
    // Card Animation: initial={{ opacity: 0, y: 40 }} -> whileInView={{ opacity: 1, y: 0 }}
    const productGrids = [
      document.querySelector('#core-lineup-section .grid'),
      document.getElementById('homepage-reviews-grid')
    ].filter(Boolean);

    productGrids.forEach((grid) => {
      const cards = Array.from(grid.children);
      if (cards.length === 0) return;

      ScrollTrigger.create({
        trigger: grid,
        start: 'top 80%', // 20% in view
        once: true,
        onEnter: () => {
          gsap.fromTo(
            cards,
            { opacity: 0, y: 40 },
            {
              opacity: 1,
              y: 0,
              duration: 0.65,
              stagger: 0.08, // Stagger delay of 0.08s between each product card
              ease: 'power3.out',
              onComplete: () => {
                cards.forEach(c => c.classList.add('animate-in'));
              }
            }
          );
        }
      });
    });

    // 3. Section Headings (Smooth upward movement y: 30 -> y: 0, duration: 0.7s)
    const headings = document.querySelectorAll('.reveal-heading');
    headings.forEach((heading) => {
      ScrollTrigger.create({
        trigger: heading,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          gsap.fromTo(
            heading,
            { opacity: 0, y: 30 },
            {
              opacity: 1,
              y: 0,
              duration: 0.7,
              ease: 'power4.out',
              onComplete: () => heading.classList.add('animate-in')
            }
          );
        }
      });
    });

    // 4. Feature Banners & Custom Cover Preview (scale: 0.96 -> scale: 1, opacity: 0 -> 1)
    const scaleBanners = document.querySelectorAll('.reveal-scale');
    scaleBanners.forEach((banner) => {
      ScrollTrigger.create({
        trigger: banner,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          gsap.fromTo(
            banner,
            { scale: 0.96, opacity: 0 },
            {
              scale: 1,
              opacity: 1,
              duration: 0.8,
              ease: 'power3.out',
              onComplete: () => banner.classList.add('animate-in')
            }
          );
        }
      });
    });

    // 5. Repair & Exchange Cards (Horizontal slide-in: Left items from x: -30, Right items from x: 30)
    const leftItems = document.querySelectorAll('.reveal-left');
    leftItems.forEach((item, idx) => {
      ScrollTrigger.create({
        trigger: item,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          gsap.fromTo(
            item,
            { opacity: 0, x: -30 },
            {
              opacity: 1,
              x: 0,
              duration: 0.7,
              delay: idx * 0.06,
              ease: 'power3.out',
              onComplete: () => item.classList.add('animate-in')
            }
          );
        }
      });
    });

    const rightItems = document.querySelectorAll('.reveal-right');
    rightItems.forEach((item, idx) => {
      ScrollTrigger.create({
        trigger: item,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          gsap.fromTo(
            item,
            { opacity: 0, x: 30 },
            {
              opacity: 1,
              x: 0,
              duration: 0.7,
              delay: idx * 0.06,
              ease: 'power3.out',
              onComplete: () => item.classList.add('animate-in')
            }
          );
        }
      });
    });
  }

  /**
   * MICRO-INTERACTIONS & HOVER STATES
   */
  initMicroInteractions() {
    // 1. Product Cards & Interactive Tiles
    const interactiveCards = document.querySelectorAll('.apple-hover-card');
    interactiveCards.forEach((card) => {
      card.addEventListener('mouseenter', () => {
        gsap.to(card, {
          y: -6,
          scale: 1.015,
          duration: 0.35,
          ease: 'power2.out',
          overwrite: 'auto'
        });
      });
      card.addEventListener('mouseleave', () => {
        gsap.to(card, {
          y: 0,
          scale: 1,
          duration: 0.35,
          ease: 'power2.out',
          overwrite: 'auto'
        });
      });
    });

    // 2. Buttons & Primary CTAs: Hover scale 1.03, Tap / Click scale 0.96
    const buttons = document.querySelectorAll('.apple-btn-interactive');
    buttons.forEach((btn) => {
      btn.addEventListener('mouseenter', () => {
        gsap.to(btn, { scale: 1.03, duration: 0.2, ease: 'power2.out', overwrite: 'auto' });
      });
      btn.addEventListener('mouseleave', () => {
        gsap.to(btn, { scale: 1.0, duration: 0.2, ease: 'power2.out', overwrite: 'auto' });
      });
      btn.addEventListener('mousedown', () => {
        gsap.to(btn, { scale: 0.96, duration: 0.1, ease: 'power2.out', overwrite: 'auto' });
      });
      btn.addEventListener('mouseup', () => {
        gsap.to(btn, { scale: 1.03, duration: 0.15, ease: 'power2.out', overwrite: 'auto' });
      });
    });

    // 3. Mega Dropdown Nav Menu: Opacity 0 -> 1, Y-axis slide -8px -> 0px, spring physics
    const navDropdownGroups = document.querySelectorAll('header nav .group');
    navDropdownGroups.forEach((group) => {
      const menu = group.querySelector('.apple-mega-menu');
      if (!menu) return;

      group.addEventListener('mouseenter', () => {
        gsap.fromTo(
          menu,
          { opacity: 0, y: -8 },
          {
            opacity: 1,
            y: 0,
            duration: 0.35,
            ease: 'back.out(1.5)',
            overwrite: 'auto'
          }
        );
      });
      group.addEventListener('mouseleave', () => {
        gsap.to(menu, {
          opacity: 0,
          y: -8,
          duration: 0.2,
          ease: 'power2.in',
          overwrite: 'auto'
        });
      });
    });
  }

  refresh() {
    ScrollTrigger.refresh();
  }
}

// Instantiate and attach globally
export const zydqoraMotion = new ZydqoraMotionEngine();
if (typeof window !== 'undefined') {
  window.zydqoraMotion = zydqoraMotion;
}
