/**
 * ZYDQORA Hardware Lineup - Side-by-Side Spec Comparison Modal
 * Pure JavaScript, Apple-Grade Minimalist Aesthetic, High-Contrast Typography
 */

export const HARDWARE_CATALOG = {
  'iphone-16-pro-max': {
    id: 'iphone-16-pro-max',
    name: 'iPhone 16 Pro Max',
    category: 'iPhone',
    tagline: 'Titanium design. A18 Pro. 48MP Fusion.',
    price: 485000,
    priceDisplay: 'PKR 485,000',
    ptaStatus: 'Official PTA Approved',
    badge: 'A18 Pro (3nm)',
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80&auto=format',
    specs: {
      displaySize: '6.9-inch',
      displayTech: 'Super Retina XDR OLED',
      refreshRate: '120Hz ProMotion',
      peakBrightness: '2,000 nits (outdoor)',
      resolution: '2868 x 1320 at 460 ppi',
      chip: 'Apple A18 Pro (3nm)',
      cpu: '6-Core (2 Perf + 4 Eff)',
      gpu: '6-Core with Ray Tracing',
      neuralEngine: '16-Core (35 TOPS)',
      memory: '8GB Unified RAM',
      storage: '256GB / 512GB / 1TB',
      mainCamera: '48MP Fusion (f/1.78)',
      zoom: '5x Optical (120mm)',
      videoCapture: '4K 120fps Dolby Vision',
      frontCamera: '12MP TrueDepth (f/1.9)',
      chassis: 'Grade 5 Titanium',
      weight: '227 grams',
      dimensions: '163.0 x 77.6 x 8.25 mm',
      batteryLife: 'Up to 33 hours video',
      charging: 'MagSafe 25W / USB-C Fast',
      ports: 'USB-C (USB 3 10Gbps)',
      connectivity: 'Wi-Fi 7 / 5G / BT 5.3',
      biometrics: 'Face ID TrueDepth'
    },
    cartPayload: {
      id: 'iphone-16-pro-max',
      name: 'iPhone 16 Pro Max',
      price: 485000,
      selectedOption: '256GB Natural Titanium',
      image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=300&q=80'
    }
  },

  'macbook-pro-16-m4': {
    id: 'macbook-pro-16-m4',
    name: 'MacBook Pro 16"',
    category: 'Mac',
    tagline: 'M4 Max extreme performance silicon.',
    price: 720000,
    priceDisplay: 'PKR 720,000',
    ptaStatus: 'Customs Cleared / Verified',
    badge: 'M4 Max Silicon',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80&auto=format',
    specs: {
      displaySize: '16.2-inch',
      displayTech: 'Liquid Retina XDR Mini-LED',
      refreshRate: '120Hz ProMotion',
      peakBrightness: '1,600 nits (HDR peak)',
      resolution: '3456 x 2234 at 254 ppi',
      chip: 'Apple M4 Max',
      cpu: 'Up to 16-Core (12P + 4E)',
      gpu: 'Up to 40-Core Metal Engine',
      neuralEngine: '16-Core (38 TOPS)',
      memory: '36GB to 128GB Unified',
      storage: '1TB / 2TB / 4TB / 8TB',
      mainCamera: '12MP Center Stage Desk View',
      zoom: 'N/A (Studio Cam)',
      videoCapture: '1080p HD Studio Stream',
      frontCamera: '12MP Center Stage',
      chassis: '100% Recycled Aluminum',
      weight: '2.15 kg',
      dimensions: '355.7 x 248.1 x 16.8 mm',
      batteryLife: 'Up to 24 hours video',
      charging: '140W USB-C / MagSafe 3',
      ports: '3x Thunderbolt 5, HDMI, SDXC',
      connectivity: 'Wi-Fi 6E / BT 5.3',
      biometrics: 'Touch ID Magic Keyboard'
    },
    cartPayload: {
      id: 'macbook-pro-16-m4',
      name: 'MacBook Pro 16 M4 Max',
      price: 720000,
      selectedOption: '36GB / 1TB Space Black',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300&q=80'
    }
  },

  'ipad-pro-13-m4': {
    id: 'ipad-pro-13-m4',
    name: 'iPad Pro 13"',
    category: 'iPad',
    tagline: '5.1mm ultra-thin Tandem OLED.',
    price: 395000,
    priceDisplay: 'PKR 395,000',
    ptaStatus: 'Official PTA Approved',
    badge: 'M4 Tandem OLED',
    image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&q=80&auto=format',
    specs: {
      displaySize: '13.0-inch',
      displayTech: 'Ultra Retina XDR Tandem OLED',
      refreshRate: '120Hz ProMotion',
      peakBrightness: '1,600 nits (HDR peak)',
      resolution: '2752 x 2064 at 264 ppi',
      chip: 'Apple M4 Chip (3nm)',
      cpu: '10-Core (4 Perf + 6 Eff)',
      gpu: '10-Core Ray Tracing',
      neuralEngine: '16-Core (38 TOPS)',
      memory: '8GB / 16GB Unified RAM',
      storage: '256GB / 512GB / 1TB / 2TB',
      mainCamera: '12MP Wide + LiDAR Scanner',
      zoom: '2x Digital / LiDAR Range',
      videoCapture: '4K ProRes at 60fps',
      frontCamera: 'Landscape 12MP TrueDepth',
      chassis: '100% Recycled Aluminum (5.1mm)',
      weight: '579 grams',
      dimensions: '281.6 x 215.5 x 5.1 mm',
      batteryLife: 'Up to 10 hours video',
      charging: 'USB-C Fast Charge (30W+)',
      ports: 'Thunderbolt 4 / USB 4',
      connectivity: 'Wi-Fi 6E / 5G Cellular / BT 5.3',
      biometrics: 'Face ID Landscape TrueDepth'
    },
    cartPayload: {
      id: 'ipad-pro-13-m4',
      name: 'iPad Pro 13 M4',
      price: 395000,
      selectedOption: '256GB Wi-Fi Space Black',
      image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=300&q=80'
    }
  },

  'iphone-16-pro': {
    id: 'iphone-16-pro',
    name: 'iPhone 16 Pro',
    category: 'iPhone',
    tagline: 'Compact 6.3-inch titanium powerhouse.',
    price: 445000,
    priceDisplay: 'PKR 445,000',
    ptaStatus: 'Official PTA Approved',
    badge: 'A18 Pro (3nm)',
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80&auto=format',
    specs: {
      displaySize: '6.3-inch',
      displayTech: 'Super Retina XDR OLED',
      refreshRate: '120Hz ProMotion',
      peakBrightness: '2,000 nits (outdoor)',
      resolution: '2622 x 1206 at 460 ppi',
      chip: 'Apple A18 Pro (3nm)',
      cpu: '6-Core (2 Perf + 4 Eff)',
      gpu: '6-Core with Ray Tracing',
      neuralEngine: '16-Core (35 TOPS)',
      memory: '8GB Unified RAM',
      storage: '128GB / 256GB / 512GB / 1TB',
      mainCamera: '48MP Fusion (f/1.78)',
      zoom: '5x Optical (120mm)',
      videoCapture: '4K 120fps Dolby Vision',
      frontCamera: '12MP TrueDepth (f/1.9)',
      chassis: 'Grade 5 Titanium',
      weight: '199 grams',
      dimensions: '149.6 x 71.5 x 8.25 mm',
      batteryLife: 'Up to 27 hours video',
      charging: 'MagSafe 25W / USB-C Fast',
      ports: 'USB-C (USB 3 10Gbps)',
      connectivity: 'Wi-Fi 7 / 5G / BT 5.3',
      biometrics: 'Face ID TrueDepth'
    },
    cartPayload: {
      id: 'iphone-16-pro',
      name: 'iPhone 16 Pro',
      price: 445000,
      selectedOption: '128GB Black Titanium',
      image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=300&q=80'
    }
  },

  'macbook-air-15-m3': {
    id: 'macbook-air-15-m3',
    name: 'MacBook Air 15"',
    category: 'Mac',
    tagline: 'Silent fanless thin and light.',
    price: 435000,
    priceDisplay: 'PKR 435,000',
    ptaStatus: 'Customs Cleared / Verified',
    badge: 'M3 Silicon',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80&auto=format',
    specs: {
      displaySize: '15.3-inch',
      displayTech: 'Liquid Retina IPS Display',
      refreshRate: '60Hz Standard',
      peakBrightness: '500 nits',
      resolution: '2880 x 1864 at 224 ppi',
      chip: 'Apple M3 Chip',
      cpu: '8-Core (4 Perf + 4 Eff)',
      gpu: '10-Core Metal Engine',
      neuralEngine: '16-Core Neural Engine',
      memory: '16GB / 24GB Unified',
      storage: '256GB / 512GB / 1TB / 2TB',
      mainCamera: '1080p FaceTime HD Camera',
      zoom: 'N/A',
      videoCapture: '1080p HD Video',
      frontCamera: '1080p FaceTime HD',
      chassis: '100% Recycled Aluminum (11.5mm)',
      weight: '1.51 kg',
      dimensions: '340.4 x 237.6 x 11.5 mm',
      batteryLife: 'Up to 18 hours video',
      charging: 'MagSafe 3 / 35W Dual USB-C',
      ports: '2x Thunderbolt / USB 4, 3.5mm',
      connectivity: 'Wi-Fi 6E / BT 5.3',
      biometrics: 'Touch ID Magic Keyboard'
    },
    cartPayload: {
      id: 'macbook-air-15-m3',
      name: 'MacBook Air 15 M3',
      price: 435000,
      selectedOption: '16GB / 512GB Midnight',
      image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300&q=80'
    }
  },

  'apple-watch-ultra-2': {
    id: 'apple-watch-ultra-2',
    name: 'Apple Watch Ultra 2',
    category: 'Watch',
    tagline: '49mm titanium rugged sport computing.',
    price: 265000,
    priceDisplay: 'PKR 265,000',
    ptaStatus: 'Official PTA Approved (eSIM)',
    badge: 'S9 SiP',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80&auto=format',
    specs: {
      displaySize: '49mm (1.92-inch)',
      displayTech: 'Always-On Retina LTPO OLED',
      refreshRate: 'Variable 1Hz - 60Hz',
      peakBrightness: '3,000 nits (direct sun)',
      resolution: '410 x 502 pixels',
      chip: 'Apple S9 SiP (64-bit)',
      cpu: 'Dual-Core S9 Processor',
      gpu: 'Apple GPU Integrated',
      neuralEngine: '4-Core Neural Engine',
      memory: '64GB Integrated',
      storage: '64GB Internal Storage',
      mainCamera: 'Precision Cardiac / Depth Sensors',
      zoom: 'N/A',
      videoCapture: 'N/A',
      frontCamera: 'N/A',
      chassis: 'Aerospace-Grade Titanium',
      weight: '61.4 grams',
      dimensions: '49.0 x 44.0 x 14.4 mm',
      batteryLife: 'Up to 36 hours (72h Low Power)',
      charging: 'Fast Magnetic Charging USB-C',
      ports: 'Water-resistant Speaker & Mic',
      connectivity: 'Cellular 4G LTE / Dual-Band GPS',
      biometrics: 'Wrist Sensor Passcode Guard'
    },
    cartPayload: {
      id: 'apple-watch-ultra-2',
      name: 'Apple Watch Ultra 2',
      price: 265000,
      selectedOption: '49mm Titanium Ocean Band',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&q=80'
    }
  }
};

export const SPEC_CATEGORIES = [
  {
    category: 'Processing & Architecture',
    specs: [
      { key: 'chip', label: 'Chipset' },
      { key: 'cpu', label: 'CPU Cores' },
      { key: 'gpu', label: 'GPU Engine' },
      { key: 'neuralEngine', label: 'Neural Engine (AI)' },
      { key: 'memory', label: 'Unified Memory' }
    ]
  },
  {
    category: 'Display & Visuals',
    specs: [
      { key: 'displaySize', label: 'Screen Size' },
      { key: 'displayTech', label: 'Panel Technology' },
      { key: 'refreshRate', label: 'Refresh Rate' },
      { key: 'peakBrightness', label: 'Peak Brightness' },
      { key: 'resolution', label: 'Native Resolution' }
    ]
  },
  {
    category: 'Camera & Optics',
    specs: [
      { key: 'mainCamera', label: 'Primary Optics' },
      { key: 'zoom', label: 'Optical Range' },
      { key: 'videoCapture', label: 'Video Capture' },
      { key: 'frontCamera', label: 'Front Sensor' }
    ]
  },
  {
    category: 'Chassis & Portability',
    specs: [
      { key: 'chassis', label: 'Frame Material' },
      { key: 'weight', label: 'Weight' },
      { key: 'dimensions', label: 'Form Factor' },
      { key: 'storage', label: 'Storage Tiers' }
    ]
  },
  {
    category: 'Battery, I/O & Security',
    specs: [
      { key: 'batteryLife', label: 'Battery Endurance' },
      { key: 'charging', label: 'Power & Charging' },
      { key: 'ports', label: 'Interface & Ports' },
      { key: 'connectivity', label: 'Wireless Networking' },
      { key: 'biometrics', label: 'Biometric Security' }
    ]
  }
];

export class SpecComparisonModal {
  constructor() {
    this.selectedIds = ['iphone-16-pro-max', 'macbook-pro-16-m4', 'ipad-pro-13-m4'];
    this.highlightDifferences = false;
    this.modalEl = null;
    this.isOpen = false;
    this.init();
  }

  init() {
    this.renderModalContainer();
    this.bindGlobalKeys();
  }

  renderModalContainer() {
    if (document.getElementById('zydqora-spec-comparison-modal')) {
      this.modalEl = document.getElementById('zydqora-spec-comparison-modal');
      return;
    }

    const modal = document.createElement('div');
    modal.id = 'zydqora-spec-comparison-modal';
    modal.className = 'fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-6 opacity-0 pointer-events-none transition-all duration-300';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-labelledby', 'spec-modal-heading');

    modal.innerHTML = `
      <!-- Backdrop with blur -->
      <div id="spec-modal-backdrop" class="absolute inset-0 bg-black/80 backdrop-blur-xl transition-opacity"></div>

      <!-- Floating Modal Card -->
      <div id="spec-modal-card" class="relative w-full max-w-6xl max-h-[92vh] bg-[#111113] border border-white/15 rounded-3xl shadow-2xl flex flex-col overflow-hidden transform scale-95 transition-all duration-300">
        
        <!-- Modal Top Bar / Header -->
        <div class="px-6 py-4 sm:px-8 sm:py-5 border-b border-white/10 bg-[#161618]/90 backdrop-blur-md flex items-center justify-between gap-4 shrink-0">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white">
              <svg class="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
              </svg>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h2 id="spec-modal-heading" class="text-base sm:text-lg font-bold tracking-tight text-white">Compare Device Specifications</h2>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30">Side-by-Side</span>
              </div>
              <p class="text-xs text-neutral-400 hidden sm:block">Detailed hardware and architecture breakdown across ZYDQORA flagships.</p>
            </div>
          </div>

          <!-- Controls: Differences Toggle & Close -->
          <div class="flex items-center gap-3">
            <button id="spec-diff-toggle" class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-white/15 bg-white/5 text-neutral-300 hover:text-white transition-all">
              <span class="w-2 h-2 rounded-full bg-neutral-500" id="spec-diff-dot"></span>
              <span>Highlight Differences</span>
            </button>
            <button id="spec-modal-close-btn" class="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 text-neutral-400 hover:text-white flex items-center justify-center transition-colors border border-white/10" aria-label="Close Comparison">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Scrollable Comparison Matrix Body -->
        <div id="spec-comparison-scroll" class="flex-1 overflow-y-auto overflow-x-auto p-4 sm:p-8 space-y-8">
          <!-- Dynamic Content rendered here -->
        </div>

        <!-- Sticky Footer bar with quick action advice -->
        <div class="px-6 py-3 border-t border-white/10 bg-[#161618] text-xs text-neutral-400 flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0">
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>All devices factory-sealed with official PTA validation & 1-Year Apple warranty.</span>
          </div>
          <div class="flex items-center gap-3 font-mono text-[11px] text-neutral-400">
            <span>Free TCS Insured Logistics</span>
            <span>•</span>
            <span>70/30 Split Support</span>
          </div>
        </div>

      </div>
    `;

    document.body.appendChild(modal);
    this.modalEl = modal;

    // Attach Backdrop & Close events
    const backdrop = modal.querySelector('#spec-modal-backdrop');
    const closeBtn = modal.querySelector('#spec-modal-close-btn');
    const diffToggle = modal.querySelector('#spec-diff-toggle');

    backdrop?.addEventListener('click', () => this.close());
    closeBtn?.addEventListener('click', () => this.close());
    diffToggle?.addEventListener('click', () => {
      this.highlightDifferences = !this.highlightDifferences;
      this.updateDiffButtonUI();
      this.renderComparisonGrid();
    });
  }

  updateDiffButtonUI() {
    const dot = document.getElementById('spec-diff-dot');
    const btn = document.getElementById('spec-diff-toggle');
    if (!dot || !btn) return;

    if (this.highlightDifferences) {
      dot.className = 'w-2 h-2 rounded-full bg-blue-400 animate-pulse';
      btn.className = 'hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-blue-500/40 bg-blue-500/15 text-blue-300 transition-all';
    } else {
      dot.className = 'w-2 h-2 rounded-full bg-neutral-500';
      btn.className = 'hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-white/15 bg-white/5 text-neutral-300 hover:text-white transition-all';
    }
  }

  bindGlobalKeys() {
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen) {
        this.close();
      }
    });
  }

  open(initialDeviceId) {
    if (!this.modalEl) this.renderModalContainer();

    if (initialDeviceId && HARDWARE_CATALOG[initialDeviceId]) {
      // Ensure the requested device is in slot 0 or within the active selection
      if (!this.selectedIds.includes(initialDeviceId)) {
        this.selectedIds[0] = initialDeviceId;
      }
    }

    this.renderComparisonGrid();

    // Show modal with animation
    this.modalEl.classList.remove('opacity-0', 'pointer-events-none');
    this.modalEl.classList.add('opacity-100', 'pointer-events-auto');

    const card = this.modalEl.querySelector('#spec-modal-card');
    card?.classList.remove('scale-95');
    card?.classList.add('scale-100');

    this.isOpen = true;
    document.body.style.overflow = 'hidden';
  }

  close() {
    if (!this.modalEl) return;

    this.modalEl.classList.add('opacity-0', 'pointer-events-none');
    this.modalEl.classList.remove('opacity-100', 'pointer-events-auto');

    const card = this.modalEl.querySelector('#spec-modal-card');
    card?.classList.add('scale-95');
    card?.classList.remove('scale-100');

    this.isOpen = false;
    document.body.style.overflow = '';
  }

  setDeviceForSlot(slotIndex, deviceId) {
    if (HARDWARE_CATALOG[deviceId]) {
      this.selectedIds[slotIndex] = deviceId;
      this.renderComparisonGrid();
    }
  }

  renderComparisonGrid() {
    const scrollContainer = document.getElementById('spec-comparison-scroll');
    if (!scrollContainer) return;

    const devices = this.selectedIds.map(id => HARDWARE_CATALOG[id] || HARDWARE_CATALOG['iphone-16-pro-max']);
    const allDeviceKeys = Object.keys(HARDWARE_CATALOG);

    // Build header column cards (Device Selectors & Images)
    let columnsHtml = '';
    devices.forEach((dev, idx) => {
      const optionsHtml = allDeviceKeys.map(k => {
        const item = HARDWARE_CATALOG[k];
        return `<option value="${item.id}" ${item.id === dev.id ? 'selected' : ''}>${item.name} (${item.category})</option>`;
      }).join('');

      columnsHtml += `
        <div class="flex-1 min-w-[240px] sm:min-w-[280px] bg-black/40 border border-white/10 rounded-2xl p-5 flex flex-col justify-between text-left space-y-4">
          
          <!-- Device Selector Dropdown -->
          <div>
            <div class="flex items-center justify-between mb-2">
              <span class="text-[10px] font-mono uppercase tracking-wider text-neutral-500">Column ${idx + 1}</span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-neutral-300">${dev.badge}</span>
            </div>
            <select data-slot="${idx}" class="spec-device-selector w-full bg-[#1c1c1f] border border-white/15 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-white/30 cursor-pointer">
              ${optionsHtml}
            </select>
          </div>

          <!-- Product Image & Basic Info -->
          <div class="flex flex-col items-center py-2">
            <img src="${dev.image}" alt="${dev.name}" class="h-32 object-contain hover:scale-105 transition-transform duration-300" />
            <h3 class="text-lg font-bold text-white mt-3 text-center">${dev.name}</h3>
            <p class="text-[11px] text-neutral-400 text-center leading-snug mt-1">${dev.tagline}</p>
            <div class="text-sm font-bold font-mono text-white mt-2">${dev.priceDisplay}</div>
            <span class="text-[10px] font-mono text-emerald-400 mt-0.5">${dev.ptaStatus}</span>
          </div>

          <!-- Direct Actions -->
          <div class="space-y-2 pt-2 border-t border-white/10">
            <button data-cart-id="${dev.id}" class="spec-add-to-bag-btn w-full py-2 rounded-xl bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-colors flex items-center justify-center gap-1.5">
              <span>Add to Bag</span>
              <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            </button>
            <button onclick="window.location.href='/store.html'" class="w-full py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-[11px] font-medium transition-colors">
              Configure in Store
            </button>
          </div>

        </div>
      `;
    });

    // Build Specifications Category Rows
    let specCategoriesHtml = '';
    SPEC_CATEGORIES.forEach(cat => {
      let rowsHtml = '';

      cat.specs.forEach(spec => {
        // Check if values across devices differ
        const values = devices.map(d => d.specs[spec.key] || '—');
        const isDifferent = new Set(values).size > 1;
        const diffHighlightClass = (this.highlightDifferences && isDifferent) 
          ? 'bg-blue-500/10 border-l-2 border-l-blue-400' 
          : 'border-l-2 border-l-transparent';

        let valColsHtml = '';
        devices.forEach((dev, dIdx) => {
          const val = dev.specs[spec.key] || '—';
          valColsHtml += `
            <div class="flex-1 min-w-[240px] sm:min-w-[280px] text-xs font-mono text-neutral-200 ${diffHighlightClass} py-2.5 px-3">
              <span class="sm:hidden block text-[10px] uppercase font-sans text-neutral-500 mb-0.5">${spec.label}</span>
              <span class="${(this.highlightDifferences && isDifferent) ? 'text-blue-200 font-semibold' : ''}">${val}</span>
            </div>
          `;
        });

        rowsHtml += `
          <div class="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
            <div class="flex flex-col sm:flex-row items-stretch">
              <div class="w-full sm:w-56 shrink-0 py-2.5 px-4 text-xs font-medium text-neutral-400 bg-black/20 flex items-center">
                <span>${spec.label}</span>
                ${(this.highlightDifferences && isDifferent) ? '<span class="ml-2 w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0"></span>' : ''}
              </div>
              <div class="flex-1 flex flex-row overflow-x-auto">
                ${valColsHtml}
              </div>
            </div>
          </div>
        `;
      });

      specCategoriesHtml += `
        <div class="rounded-2xl bg-black/30 border border-white/10 overflow-hidden shadow-inner">
          <div class="px-4 py-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
            <h4 class="text-xs font-bold uppercase tracking-wider text-neutral-300 font-mono">${cat.category}</h4>
            <span class="text-[10px] text-neutral-500 font-mono">${cat.specs.length} specs</span>
          </div>
          <div>
            ${rowsHtml}
          </div>
        </div>
      `;
    });

    scrollContainer.innerHTML = `
      <!-- Top Cards Grid (Device Selectors) -->
      <div class="flex flex-col">
        <div class="flex flex-row gap-4 overflow-x-auto pb-4 no-scrollbar">
          <div class="w-full sm:w-56 shrink-0 hidden sm:flex flex-col justify-center p-4 bg-white/5 rounded-2xl border border-white/10 text-left">
            <span class="text-[10px] font-mono uppercase text-blue-400 tracking-wider">Lineup Comparison</span>
            <div class="text-sm font-bold text-white mt-1">Select Models</div>
            <p class="text-[11px] text-neutral-400 mt-1">Switch dropdowns to dynamically compare any flagships side-by-side.</p>
            <div class="mt-4 pt-3 border-t border-white/10 text-[10px] text-neutral-500 font-mono">
              3-Column View Active
            </div>
          </div>
          <div class="flex-1 flex flex-row gap-4 overflow-x-auto no-scrollbar">
            ${columnsHtml}
          </div>
        </div>
      </div>

      <!-- Spec Tables by Category -->
      <div class="space-y-6">
        ${specCategoriesHtml}
      </div>
    `;

    // Bind event listeners for dropdowns
    const dropdowns = scrollContainer.querySelectorAll('.spec-device-selector');
    dropdowns.forEach(dd => {
      dd.addEventListener('change', (e) => {
        const target = e.target;
        const slot = parseInt(target.getAttribute('data-slot') || '0', 10);
        this.setDeviceForSlot(slot, target.value);
      });
    });

    // Bind Add to Bag buttons
    const bagButtons = scrollContainer.querySelectorAll('.spec-add-to-bag-btn');
    bagButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = btn.getAttribute('data-cart-id');
        const dev = HARDWARE_CATALOG[id];
        if (dev && window.cartDrawer) {
          window.cartDrawer.addItem(dev.cartPayload);
          if (window.authGuard) {
            window.authGuard.showToast(`${dev.name} added to shopping bag.`, 'success');
          }
        }
      });
    });
  }
}

// Global Singleton Initialization
if (typeof window !== 'undefined') {
  window.specComparisonModal = new SpecComparisonModal();
}
