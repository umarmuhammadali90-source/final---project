/**
 * ZYDQORA Interactive Pakistan Store & Repair Hub Network
 * Powered by Leaflet.js with Province -> City -> Area multi-tier filtering.
 * Strictly adheres to Apple Minimalist Aesthetics (Zero Emojis, Pure SVG Icons).
 */
import L from 'leaflet';

export const serviceHubs = [
  {
    id: 'khi-nazimabad',
    name: 'ZYDQORA Authorized Hub - North Nazimabad',
    province: 'sindh',
    city: 'karachi',
    area: 'north-nazimabad',
    lat: 24.9380,
    lng: 67.0382,
    address: 'Block D, Hyderi Market, North Nazimabad, Karachi',
    phone: '+92 21 3664 9012',
    techs: 8,
    rating: '4.9',
    repairsToday: 34,
    expressAvailable: true
  },
  {
    id: 'khi-clifton',
    name: 'ZYDQORA Flagship Store & Studio - Clifton',
    province: 'sindh',
    city: 'karachi',
    area: 'clifton',
    lat: 24.8138,
    lng: 67.0319,
    address: 'Block 4, Ocean Mall Avenue, Clifton, Karachi',
    phone: '+92 21 3582 4410',
    techs: 12,
    rating: '5.0',
    repairsToday: 52,
    expressAvailable: true
  },
  {
    id: 'khi-dha',
    name: 'ZYDQORA Pro Lab - DHA Phase 6',
    province: 'sindh',
    city: 'karachi',
    area: 'dha',
    lat: 24.8021,
    lng: 67.0654,
    address: 'Khayaban-e-Shahbaz, Phase 6, DHA Karachi',
    phone: '+92 21 3534 8820',
    techs: 10,
    rating: '4.9',
    repairsToday: 41,
    expressAvailable: true
  },
  {
    id: 'lhr-gulberg',
    name: 'ZYDQORA Experience Hub - Gulberg III',
    province: 'punjab',
    city: 'lahore',
    area: 'gulberg',
    lat: 31.5204,
    lng: 74.3587,
    address: 'MM Alam Road, Gulberg III, Lahore',
    phone: '+92 42 3575 1190',
    techs: 14,
    rating: '5.0',
    repairsToday: 68,
    expressAvailable: true
  },
  {
    id: 'lhr-dha',
    name: 'ZYDQORA Micro-Repair Lab - DHA Phase 5',
    province: 'punjab',
    city: 'lahore',
    area: 'dha',
    lat: 31.4697,
    lng: 74.4089,
    address: 'Commercial Sector C, DHA Phase 5, Lahore',
    phone: '+92 42 3718 2230',
    techs: 9,
    rating: '4.9',
    repairsToday: 39,
    expressAvailable: true
  },
  {
    id: 'isb-bluearea',
    name: 'ZYDQORA Capital Flagship - Blue Area',
    province: 'isb',
    city: 'islamabad',
    area: 'blue-area',
    lat: 33.7100,
    lng: 73.0600,
    address: 'Jinnah Avenue, Blue Area, Islamabad',
    phone: '+92 51 280 5510',
    techs: 11,
    rating: '5.0',
    repairsToday: 47,
    expressAvailable: true
  },
  {
    id: 'rwp-saddar',
    name: 'ZYDQORA Authorized Service - Saddar',
    province: 'punjab',
    city: 'rawalpindi',
    area: 'saddar',
    lat: 33.5973,
    lng: 73.0550,
    address: 'Bank Road, Saddar, Rawalpindi',
    phone: '+92 51 556 3320',
    techs: 7,
    rating: '4.8',
    repairsToday: 26,
    expressAvailable: true
  },
  {
    id: 'pew-cantt',
    name: 'ZYDQORA Tech Center - Peshawar Cantt',
    province: 'kpk',
    city: 'peshawar',
    area: 'cantt',
    lat: 34.0080,
    lng: 71.5420,
    address: 'Saddar Road, Cantt, Peshawar',
    phone: '+92 91 527 8840',
    techs: 6,
    rating: '4.8',
    repairsToday: 22,
    expressAvailable: true
  }
];

export class PakistanMapHub {
  constructor(mapContainerId = 'pakistan-network-map') {
    this.container = document.getElementById(mapContainerId);
    if (!this.container) return;

    this.map = L.map(mapContainerId, {
      center: [30.3753, 69.3451], // Center of Pakistan
      zoom: 5.5,
      scrollWheelZoom: false
    });

    // Clean Apple-style monochrome map tile
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://carto.com/">CARTO</a> | ZYDQORA Network',
      maxZoom: 18
    }).addTo(this.map);

    this.markersGroup = L.layerGroup().addTo(this.map);
    this.activeFilter = { province: 'all', city: 'all', area: 'all' };

    this.renderMarkers(serviceHubs);
    this.bindControls();
  }

  renderMarkers(hubs) {
    this.markersGroup.clearLayers();

    const customIcon = L.divIcon({
      className: 'zydqora-map-pin',
      html: `
        <div class="w-8 h-8 rounded-full bg-neutral-900 dark:bg-white text-amber-500 dark:text-amber-500 flex items-center justify-center shadow-2xl border-2 border-amber-400 dark:border-amber-400 transform hover:scale-125 transition-transform duration-200 cursor-pointer">
          <svg class="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
            <path d="M15.2 2.2c-.8 1.1-2 1.8-3.4 1.7.2-1.4 1-2.6 2.2-3.3 1.1-.7 2.6-.8 3-.6-.1 1-.7 1.7-1.8 2.2z M12.5 5.5c-4 0-8 3-8.7 7.5-.7 4.5 1.6 8.8 5.6 10.2 2.7.9 6 0 8.3-2.4 1-1 1.6-2.5 1.8-4-2.3-.3-4-2.3-4-4.8s1.7-4.5 4-4.8c-.5-1-3.3-1.7-7-1.7z"/>
          </svg>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16]
    });

    hubs.forEach(hub => {
      const marker = L.marker([hub.lat, hub.lng], { icon: customIcon });
      
      const popupHtml = `
        <div class="p-3 font-sans max-w-[240px]">
          <div class="flex items-center justify-between gap-2 mb-1">
            <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-800 font-bold">${hub.rating} / 5.0</span>
            <span class="text-[10px] text-emerald-600 font-medium">${hub.expressAvailable ? '2-Hr Express' : 'Standard'}</span>
          </div>
          <h4 class="text-xs font-bold text-neutral-900 mb-1 leading-tight">${hub.name}</h4>
          <p class="text-[11px] text-neutral-600 mb-2 leading-relaxed">${hub.address}</p>
          <div class="text-[10px] text-neutral-500 border-t pt-1.5 flex justify-between">
            <span>Techs: <strong>${hub.techs}</strong></span>
            <span>Repairs Today: <strong>${hub.repairsToday}</strong></span>
          </div>
          <a href="/repair.html" class="mt-2 block w-full text-center py-1.5 bg-neutral-900 text-white rounded-lg text-[10px] font-medium hover:bg-black transition-colors">Book Repair Slot</a>
        </div>
      `;

      marker.bindPopup(popupHtml);
      this.markersGroup.addLayer(marker);
    });

    this.renderHubCards(hubs);
  }

  renderHubCards(hubs) {
    const list = document.getElementById('map-hub-cards-list');
    if (!list) return;

    if (hubs.length === 0) {
      list.innerHTML = `
        <div class="p-8 text-center text-xs text-neutral-500">
          No service hubs found for the selected area filter.
        </div>
      `;
      return;
    }

    list.innerHTML = hubs.map(hub => `
      <div class="p-4 rounded-2xl bg-neutral-100/80 dark:bg-white/5 border border-neutral-200 dark:border-white/10 hover:border-neutral-400 transition-all">
        <div class="flex items-start justify-between gap-2 mb-2">
          <h4 class="text-xs font-semibold text-neutral-900 dark:text-white">${hub.name}</h4>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-mono font-medium">${hub.rating} / 5.0</span>
        </div>
        <p class="text-[11px] text-neutral-500 dark:text-neutral-400 mb-3">${hub.address}</p>
        <div class="flex items-center justify-between text-[11px] text-neutral-600 dark:text-neutral-300">
          <span class="flex items-center gap-1">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
            ${hub.phone}
          </span>
          <button onclick="window.location.href='/repair.html'" class="px-2.5 py-1 rounded-lg bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 text-[10px] font-medium hover:opacity-90">Schedule Visit</button>
        </div>
      </div>
    `).join('');
  }

  bindControls() {
    const provinceSelect = document.getElementById('filter-province');
    const citySelect = document.getElementById('filter-city');
    const areaSelect = document.getElementById('filter-area');

    const applyFilter = () => {
      const p = provinceSelect?.value || 'all';
      const c = citySelect?.value || 'all';
      const a = areaSelect?.value || 'all';

      const filtered = serviceHubs.filter(h => {
        const matchP = p === 'all' || h.province === p;
        const matchC = c === 'all' || h.city === c;
        const matchA = a === 'all' || h.area === a;
        return matchP && matchC && matchA;
      });

      this.renderMarkers(filtered);

      if (filtered.length === 1) {
        this.map.flyTo([filtered[0].lat, filtered[0].lng], 13);
      } else if (filtered.length > 1) {
        const group = L.featureGroup(filtered.map(h => L.marker([h.lat, h.lng])));
        this.map.fitBounds(group.getBounds().pad(0.2));
      }
    };

    provinceSelect?.addEventListener('change', () => {
      const p = provinceSelect.value;
      if (citySelect) {
        if (p === 'sindh') citySelect.innerHTML = `<option value="all">All Cities in Sindh</option><option value="karachi">Karachi</option>`;
        else if (p === 'punjab') citySelect.innerHTML = `<option value="all">All Cities in Punjab</option><option value="lahore">Lahore</option><option value="rawalpindi">Rawalpindi</option>`;
        else if (p === 'isb') citySelect.innerHTML = `<option value="islamabad">Islamabad</option>`;
        else if (p === 'kpk') citySelect.innerHTML = `<option value="peshawar">Peshawar</option>`;
        else citySelect.innerHTML = `<option value="all">All Cities</option><option value="karachi">Karachi</option><option value="lahore">Lahore</option><option value="islamabad">Islamabad</option><option value="rawalpindi">Rawalpindi</option><option value="peshawar">Peshawar</option>`;
      }
      applyFilter();
    });

    citySelect?.addEventListener('change', applyFilter);
    areaSelect?.addEventListener('change', applyFilter);
  }
}
