/**
 * ZYDQORA Reviews & User Achievement Engine
 * Manages 5-star product reviews and gamified milestone badges using Firestore.
 * Strictly adheres to Apple Minimalist Aesthetics (Zero Emojis, Pure SVG Icons).
 */
import { 
  db, 
  auth, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  serverTimestamp 
} from './firebase-config.js';

// Pre-defined System Achievements Catalog (Apple Minimalist Monochrome Series)
export const ACHIEVEMENTS_CATALOG = [
  {
    id: 'first_purchase',
    title: 'Pioneer Hardware Owner',
    category: 'Hardware',
    description: 'Completed your first flagship Apple hardware acquisition on ZYDQORA.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>`
  },
  {
    id: 'first_customization',
    title: 'Studio Artisan',
    category: 'Studio',
    description: 'Designed and saved a precision 3M vinyl skin in the Customizer Studio.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>`
  },
  {
    id: 'first_repair_gig',
    title: 'Repair Patron',
    category: 'Services',
    description: 'Posted a certified hardware diagnostic gig or successfully engaged a technician.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"/></svg>`
  },
  {
    id: 'first_review',
    title: 'Verified Critic',
    category: 'Community',
    description: 'Published an in-depth 5-star rating and technical evaluation for Apple silicon.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>`
  },
  {
    id: 'ecosystem_explorer',
    title: 'Ecosystem Explorer',
    category: 'Discovery',
    description: 'Completed the interactive Apple-grade onboarding tour and product journey.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>`
  },
  {
    id: 'flexpay_pioneer',
    title: 'FlexPay Strategist',
    category: 'Hardware',
    description: 'Calculated and configured a 0% markup trade-in installment schedule.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>`
  },
  {
    id: 'titanium_custodian',
    title: 'Titanium Grade 5',
    category: 'Hardware',
    description: 'Explored the micro-blasted Grade 5 Titanium exploded assembly view.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>`
  },
  {
    id: 'qora_ai_colleague',
    title: 'Neural Collaborator',
    category: 'Discovery',
    description: 'Engaged with QORA AI Gemini intelligence for hardware diagnostics.',
    iconSvg: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>`
  }
];

export class ReviewsAchievementsManager {
  constructor() {
    this.userAchievements = new Set();
    this.currentFilter = 'All';
    this.initReviewModal();
  }

  // ---------------------------------------------------------------------------
  // 1. ACHIEVEMENTS RETRIEVAL & PERSISTENCE ENGINE
  // ---------------------------------------------------------------------------
  async loadUserAchievements(userId) {
    if (!userId) return [];
    try {
      const docRef = doc(db, 'user_achievements', userId);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        const unlockedIds = data.unlocked || [];
        this.userAchievements = new Set(unlockedIds);
        return unlockedIds;
      }
      return [];
    } catch (err) {
      console.warn('Could not load user achievements from remote, checking local fallback:', err.message);
      const local = JSON.parse(localStorage.getItem(`zydqora_achievements_${userId}`) || '[]');
      this.userAchievements = new Set(local);
      return local;
    }
  }

  /**
   * Retrieves full details of the user's earned badges from Firestore
   * @param {string} userId - Optional user ID (defaults to current authenticated user)
   * @returns {Promise<{unlockedBadges: Array, lockedBadges: Array, unlockedIds: Array, totalCount: number, unlockedCount: number, completionPercent: number}>}
   */
  async getUserEarnedBadges(userId = null) {
    const targetUserId = userId || (auth.currentUser ? auth.currentUser.uid : null);
    let unlockedIds = [];

    if (targetUserId) {
      unlockedIds = await this.loadUserAchievements(targetUserId);
    } else {
      // Local guest fallback check
      unlockedIds = Array.from(this.userAchievements);
    }

    const unlockedBadges = ACHIEVEMENTS_CATALOG.filter(b => unlockedIds.includes(b.id));
    const lockedBadges = ACHIEVEMENTS_CATALOG.filter(b => !unlockedIds.includes(b.id));
    const totalCount = ACHIEVEMENTS_CATALOG.length;
    const unlockedCount = unlockedBadges.length;
    const completionPercent = Math.round((unlockedCount / totalCount) * 100);

    return {
      unlockedBadges,
      lockedBadges,
      unlockedIds,
      totalCount,
      unlockedCount,
      completionPercent
    };
  }

  async awardAchievement(achievementId) {
    const user = auth.currentUser;
    if (!user) return;

    if (this.userAchievements.has(achievementId)) return; // Already unlocked

    const ach = ACHIEVEMENTS_CATALOG.find(a => a.id === achievementId);
    if (!ach) return;

    this.userAchievements.add(achievementId);
    const unlockedArray = Array.from(this.userAchievements);

    // Save locally
    localStorage.setItem(`zydqora_achievements_${user.uid}`, JSON.stringify(unlockedArray));

    // Save to Firestore
    try {
      const docRef = doc(db, 'user_achievements', user.uid);
      await setDoc(docRef, {
        userId: user.uid,
        userEmail: user.email,
        unlocked: unlockedArray,
        lastUpdated: serverTimestamp()
      }, { merge: true });
    } catch (err) {
      console.warn('Failed to sync achievement to cloud:', err.message);
    }

    // Trigger Apple-Style Toast Notification
    this.showAchievementToast(ach);

    // Dispatch global event for profile refresh
    window.dispatchEvent(new CustomEvent('zydqora:achievementUnlocked', { 
      detail: { achievementId, achievement: ach } 
    }));
  }

  showAchievementToast(ach) {
    let container = document.getElementById('zydqora-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'zydqora-toast-container';
      container.className = 'fixed bottom-6 right-6 z-[10000] flex flex-col gap-2 pointer-events-none';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'px-4 py-3.5 rounded-2xl bg-black/90 dark:bg-white/95 text-white dark:text-black border border-white/20 dark:border-black/20 backdrop-blur-xl shadow-2xl text-xs font-medium max-w-sm transform translate-y-4 opacity-0 transition-all duration-300 pointer-events-auto flex items-center gap-3';
    
    toast.innerHTML = `
      <div class="w-9 h-9 rounded-xl bg-white/10 dark:bg-black/10 flex items-center justify-center text-white dark:text-black shrink-0">
        ${ach.iconSvg}
      </div>
      <div class="flex-1 min-w-0">
        <div class="text-[10px] font-mono uppercase tracking-wider text-neutral-400 dark:text-neutral-500">Achievement Unlocked</div>
        <div class="font-semibold text-xs truncate">${ach.title}</div>
        <div class="text-[11px] text-neutral-300 dark:text-neutral-600 line-clamp-1">${ach.description}</div>
      </div>
    `;

    container.appendChild(toast);
    requestAnimationFrame(() => toast.classList.remove('translate-y-4', 'opacity-0'));

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 5000);
  }

  // ---------------------------------------------------------------------------
  // 2. MY ACHIEVEMENTS PROFILE SECTION RENDERER (RADICAL APPLE MINIMALISM)
  // ---------------------------------------------------------------------------
  /**
   * Retrieves user's badges from Firestore and renders the elegant 'My Achievements' section.
   * Uses CSS to display badges as elegant, minimalist monochrome icons.
   */
  async renderMyAchievementsSection(targetContainerId, userId = null) {
    const container = typeof targetContainerId === 'string' 
      ? document.getElementById(targetContainerId) 
      : targetContainerId;

    if (!container) return;

    // Show Apple-grade skeleton shimmer while loading
    container.innerHTML = `
      <div class="py-8 flex flex-col items-center justify-center text-center space-y-3">
        <div class="w-6 h-6 border-2 border-neutral-300 dark:border-neutral-700 border-t-neutral-900 dark:border-t-white rounded-full animate-spin"></div>
        <p class="text-xs text-neutral-400 font-mono uppercase tracking-wider">Syncing Milestone Telemetry...</p>
      </div>
    `;

    const data = await this.getUserEarnedBadges(userId);
    const categories = ['All', 'Hardware', 'Studio', 'Services', 'Community', 'Discovery'];

    const renderBadges = (filter = 'All') => {
      this.currentFilter = filter;
      const filteredBadges = ACHIEVEMENTS_CATALOG.filter(ach => {
        if (filter === 'All') return true;
        return ach.category === filter;
      });

      return `
        <!-- Minimalist Category Filter Pills -->
        <div class="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 mb-4">
          ${categories.map(cat => `
            <button 
              type="button" 
              data-category="${cat}"
              class="achievement-filter-btn px-3 py-1.5 rounded-full text-[11px] font-medium transition-all duration-200 whitespace-nowrap ${
                this.currentFilter === cat 
                  ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-sm' 
                  : 'bg-neutral-100 dark:bg-white/5 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-white/10'
              }"
            >
              ${cat}
            </button>
          `).join('')}
        </div>

        <!-- Monochrome Badges Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[340px] overflow-y-auto pr-1 select-none">
          ${filteredBadges.map(ach => {
            const isUnlocked = data.unlockedIds.includes(ach.id);
            return `
              <div class="group relative p-4 rounded-2xl border transition-all duration-300 ${
                isUnlocked 
                  ? 'bg-neutral-50 dark:bg-neutral-900/60 border-neutral-300/80 dark:border-neutral-700/80 shadow-sm hover:border-neutral-400 dark:hover:border-neutral-500' 
                  : 'bg-neutral-50/30 dark:bg-white/[0.01] border-neutral-200/40 dark:border-white/5 opacity-60 hover:opacity-80'
              }">
                <div class="flex items-start justify-between gap-3 mb-2.5">
                  <!-- Elegant Monochrome Icon Badge -->
                  <div class="w-10 h-10 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-105 ${
                    isUnlocked 
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-md ring-1 ring-black/10 dark:ring-white/20' 
                      : 'bg-neutral-200/70 text-neutral-400 dark:bg-white/5 dark:text-neutral-500 border border-neutral-300/50 dark:border-white/10'
                  }">
                    ${ach.iconSvg}
                  </div>
                  
                  <div class="flex flex-col items-end gap-1">
                    <span class="text-[9px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                      isUnlocked 
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 border-transparent font-semibold' 
                        : 'bg-transparent text-neutral-400 dark:text-neutral-500 border-neutral-200 dark:border-neutral-800'
                    }">
                      ${isUnlocked ? 'Unlocked' : 'Locked'}
                    </span>
                    <span class="text-[9px] text-neutral-400 dark:text-neutral-500 font-mono">${ach.category}</span>
                  </div>
                </div>

                <h4 class="text-xs font-bold tracking-tight text-neutral-900 dark:text-white group-hover:text-neutral-700 dark:group-hover:text-neutral-200 transition-colors">
                  ${ach.title}
                </h4>
                <p class="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 leading-relaxed">
                  ${ach.description}
                </p>
              </div>
            `;
          }).join('')}
        </div>
      `;
    };

    container.innerHTML = `
      <div class="my-achievements-section space-y-4 text-neutral-900 dark:text-white">
        <!-- Section Header & Progress Summary -->
        <div class="p-5 rounded-2xl bg-neutral-100/70 dark:bg-white/[0.03] border border-neutral-200/80 dark:border-white/10">
          <div class="flex items-center justify-between gap-4 mb-2.5">
            <div>
              <span class="text-[10px] font-mono uppercase tracking-widest text-neutral-400 dark:text-neutral-500">Hardware &amp; Craft Milestones</span>
              <h3 class="text-sm font-bold tracking-tight text-neutral-900 dark:text-white">My Achievements</h3>
            </div>
            <div class="text-right">
              <span class="text-xs font-mono font-bold text-neutral-900 dark:text-white">${data.unlockedCount} / ${data.totalCount}</span>
              <span class="text-[10px] text-neutral-400 block font-mono">(${data.completionPercent}%)</span>
            </div>
          </div>

          <!-- Minimalist Monochrome Progress Bar -->
          <div class="w-full h-1.5 rounded-full bg-neutral-200 dark:bg-white/10 overflow-hidden">
            <div class="h-full bg-neutral-900 dark:bg-white transition-all duration-500 ease-out" style="width: ${data.completionPercent}%"></div>
          </div>
        </div>

        <!-- Filterable Content Area -->
        <div id="achievements-interactive-grid">
          ${renderBadges('All')}
        </div>
      </div>
    `;

    // Attach Category Filter Listeners
    const bindFilterEvents = () => {
      const filterBtns = container.querySelectorAll('.achievement-filter-btn');
      filterBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
          const cat = btn.getAttribute('data-category');
          const gridWrapper = container.querySelector('#achievements-interactive-grid');
          if (gridWrapper) {
            gridWrapper.innerHTML = renderBadges(cat);
            bindFilterEvents();
          }
        });
      });
    };

    bindFilterEvents();
  }

  renderAchievementsGrid(containerId, unlockedIds = []) {
    this.renderMyAchievementsSection(containerId);
  }

  // ---------------------------------------------------------------------------
  // 3. PRODUCT REVIEWS & RATING ENGINE
  // ---------------------------------------------------------------------------
  async submitReview({ productId, productName, rating, title, comment }) {
    const user = auth.currentUser;
    if (!user) {
      if (window.authGuard) window.authGuard.openModal('login');
      return { success: false, error: 'Authentication required' };
    }

    try {
      const reviewData = {
        productId,
        productName: productName || productId,
        rating: Number(rating),
        title: title.trim(),
        comment: comment.trim(),
        userId: user.uid,
        userName: user.displayName || user.email.split('@')[0],
        userEmail: user.email,
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'product_reviews'), reviewData);

      // Award Reviewer Achievement
      this.awardAchievement('first_review');

      if (window.authGuard) {
        window.authGuard.showToast('Review published successfully.', 'success');
      }

      return { success: true };
    } catch (err) {
      console.error('Error adding review:', err);
      // Fallback local persistence
      const localReviews = JSON.parse(localStorage.getItem(`zydqora_reviews_${productId}`) || '[]');
      localReviews.unshift({
        productId,
        productName,
        rating: Number(rating),
        title,
        comment,
        userId: user.uid,
        userName: user.displayName || 'Verified Buyer',
        createdAt: new Date().toISOString()
      });
      localStorage.setItem(`zydqora_reviews_${productId}`, JSON.stringify(localReviews));
      this.awardAchievement('first_review');
      return { success: true, offline: true };
    }
  }

  async getReviewsForProduct(productId) {
    try {
      const q = query(
        collection(db, 'product_reviews'),
        where('productId', '==', productId)
      );
      const snap = await getDocs(q);
      const list = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() }));

      if (list.length === 0) {
        return this.getSeedReviews(productId);
      }
      return list;
    } catch (err) {
      console.warn('Using local seeded reviews:', err.message);
      const local = JSON.parse(localStorage.getItem(`zydqora_reviews_${productId}`) || '[]');
      if (local.length > 0) return local;
      return this.getSeedReviews(productId);
    }
  }

  getSeedReviews(productId) {
    return [
      {
        id: 'seed-1',
        productId,
        rating: 5,
        title: 'Impeccable build and blistering performance',
        comment: 'The Grade 5 Titanium finish feels noticeably lighter in hand. The A18 Pro silicon handles intense 4K ProRes workflows without noticeable thermal throttling.',
        userName: 'Hamza Khan',
        createdAt: '2 days ago'
      },
      {
        id: 'seed-2',
        productId,
        rating: 5,
        title: 'TCS delivery was fast & 70/30 split was seamless',
        comment: 'Authentic PTA approved unit with official warranty card. The ZYDQORA checkout handled the 70% deposit effortlessly.',
        userName: 'Zainab Tariq',
        createdAt: '5 days ago'
      },
      {
        id: 'seed-3',
        productId,
        rating: 4,
        title: 'Outstanding display fidelity',
        comment: 'Super Retina XDR OLED provides surgical color calibration. Battery easily survives a grueling 14-hour workday in Lahore.',
        userName: 'Bilal Ahmed',
        createdAt: '1 week ago'
      }
    ];
  }

  calculateAverageRating(reviews) {
    if (!reviews || reviews.length === 0) return { avg: 5.0, count: 0 };
    const sum = reviews.reduce((acc, r) => acc + Number(r.rating || 5), 0);
    return {
      avg: (sum / reviews.length).toFixed(1),
      count: reviews.length
    };
  }

  renderStarsSvg(rating, size = 'w-3.5 h-3.5') {
    const stars = [];
    const rounded = Math.round(rating);
    for (let i = 1; i <= 5; i++) {
      if (i <= rounded) {
        stars.push(`<svg class="${size} text-neutral-900 dark:text-white fill-current" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`);
      } else {
        stars.push(`<svg class="${size} text-neutral-300 dark:text-neutral-700 fill-current" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>`);
      }
    }
    return `<div class="flex items-center gap-0.5">${stars.join('')}</div>`;
  }

  initReviewModal() {
    if (document.getElementById('zydqora-review-modal')) return;

    const modalHtml = `
      <div id="zydqora-review-modal" class="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md opacity-0 pointer-events-none transition-all duration-300">
        <div id="review-modal-card" class="w-full max-w-lg bg-white dark:bg-[#161617] border border-neutral-200 dark:border-white/10 rounded-3xl p-8 shadow-2xl text-neutral-900 dark:text-white transform scale-95 transition-all duration-300 relative overflow-hidden">
          
          <button id="review-modal-close" class="absolute top-5 right-5 w-8 h-8 rounded-full bg-neutral-100 dark:bg-white/10 hover:bg-neutral-200 dark:hover:bg-white/20 flex items-center justify-center text-neutral-500 dark:text-neutral-400 hover:text-black dark:hover:text-white transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </button>

          <div class="mb-6">
            <span class="text-[10px] font-mono uppercase tracking-wider text-neutral-500">Verified Hardware Evaluation</span>
            <h3 class="text-xl font-bold tracking-tight text-neutral-900 dark:text-white mt-1" id="review-modal-product-title">Rate &amp; Review Product</h3>
            <p class="text-xs text-neutral-500 dark:text-neutral-400 mt-1">Share technical feedback and build quality impressions with the community.</p>
          </div>

          <form id="review-submission-form" class="space-y-4">
            <input type="hidden" id="review-target-product-id" value="" />
            <input type="hidden" id="review-target-product-name" value="" />

            <!-- 5-Star Interactive Selector -->
            <div>
              <label class="block text-[11px] font-medium uppercase tracking-wider text-neutral-500 mb-1.5">Rating (1 to 5 Stars)</label>
              <div class="flex items-center gap-2" id="star-rating-selector">
                ${[1, 2, 3, 4, 5].map(star => `
                  <button type="button" data-star="${star}" class="star-btn p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-white/10 transition-colors">
                    <svg class="w-6 h-6 text-neutral-300 dark:text-neutral-700 fill-current hover:text-amber-400 transition-colors" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                  </button>
                `).join('')}
                <span id="selected-star-label" class="text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 ml-2">5.0 / 5.0</span>
              </div>
              <input type="hidden" id="review-rating-value" value="5" />
            </div>

            <!-- Review Title -->
            <div>
              <label class="block text-[11px] font-medium uppercase tracking-wider text-neutral-500 mb-1">Headline</label>
              <input type="text" id="review-headline-input" required placeholder="Summarize your key evaluation" class="w-full px-4 py-2.5 bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 rounded-xl text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-neutral-400 dark:focus:border-white/30" />
            </div>

            <!-- Written Comment -->
            <div>
              <label class="block text-[11px] font-medium uppercase tracking-wider text-neutral-500 mb-1">Detailed Technical Review</label>
              <textarea id="review-comment-input" rows="4" required placeholder="Describe build quality, battery endurance, display calibration, and packaging..." class="w-full px-4 py-2.5 bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 rounded-xl text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-neutral-400 dark:focus:border-white/30 resize-none"></textarea>
            </div>

            <button type="submit" id="review-submit-btn" class="w-full py-3 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-semibold text-xs tracking-wider uppercase rounded-xl hover:opacity-90 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-lg">
              <span>Submit Evaluation</span>
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </button>
          </form>

        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    this.bindReviewModalEvents();
  }

  bindReviewModalEvents() {
    const modal = document.getElementById('zydqora-review-modal');
    const card = document.getElementById('review-modal-card');
    const closeBtn = document.getElementById('review-modal-close');
    const form = document.getElementById('review-submission-form');
    const starBtns = document.querySelectorAll('.star-btn');
    const ratingInput = document.getElementById('review-rating-value');
    const ratingLabel = document.getElementById('selected-star-label');

    const updateStarUI = (val) => {
      ratingInput.value = val;
      ratingLabel.textContent = `${val}.0 / 5.0`;
      starBtns.forEach(btn => {
        const starNum = Number(btn.getAttribute('data-star'));
        const svg = btn.querySelector('svg');
        if (starNum <= val) {
          svg.classList.remove('text-neutral-300', 'dark:text-neutral-700');
          svg.classList.add('text-neutral-900', 'dark:text-white');
        } else {
          svg.classList.add('text-neutral-300', 'dark:text-neutral-700');
          svg.classList.remove('text-neutral-900', 'dark:text-white');
        }
      });
    };

    starBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const val = Number(btn.getAttribute('data-star'));
        updateStarUI(val);
      });
    });

    updateStarUI(5);

    closeBtn?.addEventListener('click', () => this.closeReviewModal());
    modal?.addEventListener('click', (e) => {
      if (e.target === modal) this.closeReviewModal();
    });

    form?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const productId = document.getElementById('review-target-product-id').value;
      const productName = document.getElementById('review-target-product-name').value;
      const rating = Number(ratingInput.value);
      const title = document.getElementById('review-headline-input').value;
      const comment = document.getElementById('review-comment-input').value;
      const submitBtn = document.getElementById('review-submit-btn');

      submitBtn.disabled = true;
      submitBtn.classList.add('opacity-50');

      await this.submitReview({ productId, productName, rating, title, comment });

      submitBtn.disabled = false;
      submitBtn.classList.remove('opacity-50');
      this.closeReviewModal();
      form.reset();
      updateStarUI(5);

      window.dispatchEvent(new CustomEvent('zydqora:reviewSubmitted', { detail: { productId } }));
    });
  }

  openReviewModal(productId = 'iphone-16-pro-max', productName = 'iPhone 16 Pro Max') {
    if (!auth.currentUser && window.authGuard) {
      window.authGuard.openModal('login');
      return;
    }

    const modal = document.getElementById('zydqora-review-modal');
    const card = document.getElementById('review-modal-card');
    const titleEl = document.getElementById('review-modal-product-title');
    const idInput = document.getElementById('review-target-product-id');
    const nameInput = document.getElementById('review-target-product-name');

    if (titleEl) titleEl.textContent = `Review: ${productName}`;
    if (idInput) idInput.value = productId;
    if (nameInput) nameInput.value = productName;

    modal?.classList.remove('opacity-0', 'pointer-events-none');
    card?.classList.remove('scale-95');
    card?.classList.add('scale-100');
  }

  closeReviewModal() {
    const modal = document.getElementById('zydqora-review-modal');
    const card = document.getElementById('review-modal-card');
    modal?.classList.add('opacity-0', 'pointer-events-none');
    card?.classList.remove('scale-100');
    card?.classList.add('scale-95');
  }
}

export const reviewsAchievements = new ReviewsAchievementsManager();

// Standalone functions for external invocation
export async function renderMyAchievements(containerId, userId = null) {
  return reviewsAchievements.renderMyAchievementsSection(containerId, userId);
}

export async function retrieveUserBadges(userId = null) {
  return reviewsAchievements.getUserEarnedBadges(userId);
}

window.reviewsAchievements = reviewsAchievements;
window.renderMyAchievements = renderMyAchievements;
window.retrieveUserBadges = retrieveUserBadges;

