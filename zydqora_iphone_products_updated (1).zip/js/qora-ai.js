/**
 * QORA AI - Apple-Grade Intelligent Assistant
 * Powered by Gemini API, anchored to the bottom-left of every page.
 * Strictly adheres to Apple Minimalist Aesthetics (Zero Emojis, Pure SVG Icons).
 */

class QoraAI {
  constructor() {
    this.isOpen = false;
    this.messages = [
      {
        role: 'assistant',
        text: 'Welcome to ZYDQORA. I am **QORA AI**, your specialized Apple ecosystem advisor. How may I assist you with flagship hardware specifications, custom vinyl decals, trade-in valuations, or repair diagnostics today?'
      }
    ];
    this.geminiApiKey = "AQ.Ab8RN6Kn94T0w2RnePYArU262-nWVKYDBSBaptv2jr-4EuoZ9w";
    this.initUI();
    this.bindEvents();
  }

  initUI() {
    if (document.getElementById('qora-ai-widget')) return;

    const widgetHtml = `
      <!-- QORA AI Floating Widget (Bottom-Left) -->
      <div id="qora-ai-widget" class="fixed bottom-6 left-6 z-[9990] font-sans">
        <!-- Floating Trigger Button -->
        <button id="qora-ai-trigger" class="relative group w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-black dark:bg-white text-white dark:text-black shadow-2xl flex items-center justify-center border border-white/20 dark:border-black/20 hover:scale-105 active:scale-95 transition-all duration-300">
          <div class="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white dark:border-black animate-pulse"></div>
          <svg class="w-5 h-5 sm:w-6 sm:h-6 transition-transform duration-300 group-hover:rotate-12" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
          </svg>
          <span class="sr-only">Open QORA AI Assistant</span>
        </button>

        <!-- Glassmorphic Chat Window -->
        <div id="qora-ai-window" class="fixed bottom-24 left-6 w-[360px] sm:w-[420px] max-w-[calc(100vw-3rem)] h-[540px] max-h-[calc(100vh-8rem)] bg-white/95 dark:bg-[#121214]/95 backdrop-blur-2xl border border-black/10 dark:border-white/10 rounded-3xl shadow-2xl flex flex-col overflow-hidden opacity-0 pointer-events-none transform -translate-y-4 scale-95 transition-all duration-300 z-50">
          
          <!-- Header -->
          <div class="px-5 py-4 border-b border-black/5 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 rounded-2xl bg-neutral-900 dark:bg-white text-white dark:text-black flex items-center justify-center font-bold text-sm shadow">
                Q
              </div>
              <div>
                <div class="flex items-center gap-1.5">
                  <h3 class="text-sm font-semibold text-neutral-900 dark:text-white">QORA AI</h3>
                  <span class="text-[10px] px-1.5 py-0.5 rounded-full bg-neutral-100 dark:bg-white/10 text-neutral-600 dark:text-neutral-300 font-mono">Gemini 3.7</span>
                </div>
                <p class="text-[11px] text-neutral-500 dark:text-neutral-400">Apple Architecture &amp; Ecosystem Intelligence</p>
              </div>
            </div>
            <div class="flex items-center gap-1">
              <button id="qora-clear-btn" title="Clear Conversation" class="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
              </button>
              <button id="qora-close-btn" class="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
          </div>

          <!-- Quick Suggestion Chips (Monochrome, Zero Emojis) -->
          <div class="px-4 py-2 border-b border-black/5 dark:border-white/5 bg-black/[0.01] dark:bg-white/[0.01] flex gap-1.5 overflow-x-auto no-scrollbar py-2 text-[11px]">
            <button class="qora-chip whitespace-nowrap px-2.5 py-1 rounded-full bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-white/20 transition-colors">iPhone 16 Pro Specs</button>
            <button class="qora-chip whitespace-nowrap px-2.5 py-1 rounded-full bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-white/20 transition-colors">Custom Vinyl Guide</button>
            <button class="qora-chip whitespace-nowrap px-2.5 py-1 rounded-full bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-white/20 transition-colors">Repair Diagnostic</button>
            <button class="qora-chip whitespace-nowrap px-2.5 py-1 rounded-full bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-white/20 transition-colors">Trade-In Schedule</button>
          </div>

          <!-- Chat Messages Body -->
          <div id="qora-messages-container" class="flex-1 p-4 overflow-y-auto space-y-3.5 text-xs">
            <!-- Messages rendered dynamically -->
          </div>

          <!-- Input Box -->
          <div class="p-3 border-t border-black/5 dark:border-white/10 bg-black/[0.01] dark:bg-white/[0.01]">
            <form id="qora-chat-form" class="flex items-center gap-2">
              <input 
                type="text" 
                id="qora-user-input" 
                placeholder="Ask about specs, vinyl wraps, repair slots..." 
                class="flex-1 px-4 py-2.5 bg-neutral-100 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl text-xs text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:border-neutral-400 dark:focus:border-white/30 transition-colors"
                autocomplete="off"
              />
              <button 
                type="button"
                id="qora-mic-btn"
                title="Voice Dictation"
                class="w-9 h-9 rounded-2xl bg-neutral-100 dark:bg-white/10 text-neutral-600 dark:text-neutral-300 hover:text-black dark:hover:text-white flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-white/20 active:scale-95 transition-all"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/>
                </svg>
              </button>
              <button 
                type="submit" 
                id="qora-send-btn"
                class="w-9 h-9 rounded-2xl bg-black dark:bg-white text-white dark:text-black flex items-center justify-center hover:opacity-90 active:scale-95 transition-all disabled:opacity-40"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                </svg>
              </button>
            </form>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', widgetHtml);
    this.renderMessages();
  }

  bindEvents() {
    const trigger = document.getElementById('qora-ai-trigger');
    const closeBtn = document.getElementById('qora-close-btn');
    const clearBtn = document.getElementById('qora-clear-btn');
    const form = document.getElementById('qora-chat-form');
    const micBtn = document.getElementById('qora-mic-btn');
    const chips = document.querySelectorAll('.qora-chip');

    // Speech recognition setup
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        micBtn?.classList.add('bg-red-500', 'text-white', 'animate-pulse');
      };

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const input = document.getElementById('qora-user-input');
        if (input) {
          input.value = transcript;
          form?.dispatchEvent(new Event('submit'));
        }
      };

      recognition.onend = () => {
        micBtn?.classList.remove('bg-red-500', 'text-white', 'animate-pulse');
      };

      micBtn?.addEventListener('click', () => {
        try {
          recognition.start();
        } catch (e) {
          recognition.stop();
        }
      });
    } else {
      micBtn?.addEventListener('click', () => {
        if (window.authGuard) window.authGuard.showToast('Voice dictation not supported on this browser.', 'info');
      });
    }

    trigger?.addEventListener('click', () => this.toggle());
    closeBtn?.addEventListener('click', () => this.close());
    clearBtn?.addEventListener('click', () => {
      this.messages = [
        {
          role: 'assistant',
          text: 'Conversation reset. How can I help you navigate ZYDQORA today?'
        }
      ];
      this.renderMessages();
    });

    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        const text = chip.textContent.trim();
        const input = document.getElementById('qora-user-input');
        if (input) {
          input.value = text;
          form.dispatchEvent(new Event('submit'));
        }
      });
    });

    form?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = document.getElementById('qora-user-input');
      const text = input.value.trim();
      if (!text) return;

      input.value = '';
      this.addMessage('user', text);
      await this.generateResponse(text);
    });
  }

  toggle() {
    if (this.isOpen) this.close();
    else this.open();
  }

  open() {
    this.isOpen = true;
    const win = document.getElementById('qora-ai-window');
    if (!win) return;
    win.classList.remove('opacity-0', 'pointer-events-none', '-translate-y-4', 'scale-95');
    win.classList.add('opacity-100', 'pointer-events-auto', 'translate-y-0', 'scale-100');
    document.getElementById('qora-user-input')?.focus();
  }

  close() {
    this.isOpen = false;
    const win = document.getElementById('qora-ai-window');
    if (!win) return;
    win.classList.remove('opacity-100', 'pointer-events-auto', 'translate-y-0', 'scale-100');
    win.classList.add('opacity-0', 'pointer-events-none', '-translate-y-4', 'scale-95');
  }

  addMessage(role, text) {
    this.messages.push({ role, text });
    this.renderMessages();
  }

  renderMessages() {
    const container = document.getElementById('qora-messages-container');
    if (!container) return;

    container.innerHTML = this.messages.map(m => {
      const isUser = m.role === 'user';
      const formatted = this.formatMarkdown(m.text);
      return `
        <div class="flex ${isUser ? 'justify-end' : 'justify-start'}">
          <div class="max-w-[85%] rounded-2xl px-3.5 py-2.5 ${
            isUser 
              ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 rounded-br-none shadow' 
              : 'bg-neutral-100 dark:bg-white/10 text-neutral-800 dark:text-neutral-200 rounded-bl-none border border-black/5 dark:border-white/5'
          } leading-relaxed">
            ${formatted}
          </div>
        </div>
      `;
    }).join('');

    container.scrollTop = container.scrollHeight;
  }

  formatMarkdown(text) {
    let out = text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code class="px-1 py-0.5 rounded bg-black/10 dark:bg-white/10 font-mono text-[11px]">$1</code>')
      .replace(/\n/g, '<br/>');
    return out;
  }

  async generateResponse(userPrompt) {
    const sendBtn = document.getElementById('qora-send-btn');
    const container = document.getElementById('qora-messages-container');

    sendBtn.disabled = true;

    // Loading indicator
    const loadingId = 'qora-loading-' + Date.now();
    container.insertAdjacentHTML('beforeend', `
      <div id="${loadingId}" class="flex justify-start">
        <div class="max-w-[85%] rounded-2xl rounded-bl-none px-3.5 py-2.5 bg-neutral-100 dark:bg-white/10 text-neutral-800 dark:text-neutral-200 border border-black/5 dark:border-white/5 flex items-center gap-1.5">
          <span class="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce"></span>
          <span class="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce [animation-delay:0.2s]"></span>
          <span class="w-1.5 h-1.5 rounded-full bg-neutral-400 animate-bounce [animation-delay:0.4s]"></span>
        </div>
      </div>
    `);
    container.scrollTop = container.scrollHeight;

    const systemInstruction = `You are QORA AI, the premier Apple Ecosystem & Engineering Software Advisor for ZYDQORA (founded and architected by Muhammad Umar, umardeveloper1@gmail.com).
Your tone is ultra-refined, concise, authoritative, and helpful like an Apple Senior Product Specialist. Zero emojis are permitted.
You provide deep technical expertise on:
1. Apple Hardware Lineup (iPhone 16 Pro/Pro Max Titanium, M4 MacBooks, Apple Watch Ultra 2, OLED iPad Pro M4, AirPods Max).
2. ZYDQORA Studio Customizer (3M vinyl skin decals, remove.bg background stripping, custom cover placement).
3. Pakistan Repair Marketplace (Posting repair gigs, verified technician proposals, transparent diagnostics in Karachi, Lahore, Islamabad, etc.).
4. Trade-in & payment splits (100% COD for <=5 items, 70/30 deposit for bulk >5 items, EasyPaisa, JazzCash, Stripe).
Keep answers crisp, elegant, structured with bullet points where appropriate, and always reflect Apple-grade precision.`;

    try {
      // First try server API endpoint
      const serverRes = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userPrompt,
          history: this.messages.slice(-6)
        })
      });

      let aiText = "";
      if (serverRes.ok) {
        const data = await serverRes.json();
        aiText = data.reply || data.text;
      } else {
        // Fallback to client-side direct call
        const directRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${this.geminiApiKey}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [
              {
                role: 'user',
                parts: [{ text: `${systemInstruction}\n\nUser Question: ${userPrompt}` }]
              }
            ],
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 600
            }
          })
        });
        const directData = await directRes.json();
        aiText = directData.candidates?.[0]?.content?.parts?.[0]?.text || "I apologize, I am temporarily unable to reach the neural engine. Please try again.";
      }

      document.getElementById(loadingId)?.remove();
      this.addMessage('assistant', aiText);
    } catch (err) {
      document.getElementById(loadingId)?.remove();
      this.addMessage('assistant', `**QORA Diagnostic Note:** ${err.message || 'Unable to connect to Gemini engine. Please check network connectivity.'}`);
    } finally {
      sendBtn.disabled = false;
    }
  }
}

export const qoraAI = new QoraAI();
window.qoraAI = qoraAI;
