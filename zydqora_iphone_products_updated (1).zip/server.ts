import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const PORT = 3000;
const app = express();

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Lazy Initialize Gemini SDK
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY || "AQ.Ab8RN6Kn94T0w2RnePYArU262-nWVKYDBSBaptv2jr-4EuoZ9w";
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return aiClient;
}

// 1. Health Endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    platform: 'ZYDQORA Enterprise Ecosystem',
    architect: 'Muhammad Umar (umardeveloper1@gmail.com)',
    timestamp: new Date().toISOString()
  });
});

// 2. Gemini QORA AI Assistant Endpoint
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { prompt, history = [] } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGeminiClient();
    const systemInstruction = `You are QORA AI, the dedicated Apple-grade Enterprise Advisor for ZYDQORA (engineered by Muhammad Umar, umardeveloper1@gmail.com).
Your tone is precise, authoritative, minimalistic, and deeply knowledgeable on Apple hardware architecture, custom vinyl decals, Pakistan repair workflows, and payment rules.
Answer the user concisely with sleek structure and bullet points where helpful.`;

    const chat = ai.chats.create({
      model: 'gemini-3.7-flash',
      config: {
        systemInstruction,
        temperature: 0.7
      }
    });

    const response = await chat.sendMessage({
      message: prompt
    });

    const text = response.text || 'I am ready to assist you with your ZYDQORA request.';
    return res.json({ reply: text });
  } catch (error: any) {
    console.error('Gemini API Server Error:', error);
    return res.status(500).json({ 
      error: 'AI Neural Engine unavailable', 
      details: error.message 
    });
  }
});

// 3. Remove.bg API Proxy
app.post('/api/remove-bg', async (req, res) => {
  try {
    const { imageBase64 } = req.body;
    const apiKey = process.env.REMOVE_BG_API_KEY || "cgywUrW6oqd48BsYTDYujbrA";

    if (!imageBase64) {
      return res.status(400).json({ error: 'Base64 image is required' });
    }

    // Strip prefix if present
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const formData = new URLSearchParams();
    formData.append('image_file_b64', base64Data);
    formData.append('size', 'auto');

    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': apiKey,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formData
    });

    if (!response.ok) {
      const errText = await response.text();
      return res.status(response.status).json({ error: 'Remove.bg API Error', details: errText });
    }

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const resultBase64 = `data:image/png;base64,${buffer.toString('base64')}`;

    return res.json({ result: resultBase64 });
  } catch (err: any) {
    console.error('Remove.bg Proxy Error:', err);
    return res.status(500).json({ error: 'Failed to process background removal', details: err.message });
  }
});

// Vite middleware for development & static serving for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ZYDQORA] Server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
